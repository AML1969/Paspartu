# Prompt cheat-sheet for reference-image generation

## Compact pattern
- **Subject**: exact person/object from the reference image
- **Action**: what they are doing
- **Scene**: where it happens
- **Composition**: camera angle, framing, motion
- **Style**: watercolor, realism, poster, etc.
- **Quality**: detailed, sharp, natural anatomy, clean background

## Session-proven phrasing
When the user wants the exact same subject from a provided photo, use wording like:

> Use the uploaded reference photo as the exact subject. Preserve face, hairstyle, age, clothing, and proportions.

Then add the scene:

> A boy riding a Soviet-era bicycle in a wheelie along a tall nine-story apartment building, with planted trees along the road in the background. He is seated and gripping the handlebars, but the front wheel is lifted so the bicycle rides only on the rear wheel.

## Good defaults
- Prefer **landscape** for action scenes.
- Specify **natural motion** and **realistic proportions** when the result should look believable.
- Add **bright daylight** or another clear lighting cue.
- Keep the prompt to the essential scene beats; image models like clean instructions more than prose.

## Avoid
- Overexplaining the request.
- Adding conflicting styles in the same prompt.
- Hiding the reference subject behind generic wording like "a boy" when the user asked for the exact boy.
