---
name: reference-image-prompting
description: "Prompting workflow for image generation from user reference photos or exact-subject requests."
version: 1.0.0
author: OpenAI
tags: [image-generation, prompting, reference-image, visual, creative]
---

# Reference Image Prompting

Use this skill when the user wants an image generated or edited from a supplied reference photo, or asks to preserve an exact subject identity/style in a new scene.

## Goal
Turn a vague art request into a strong generation prompt that preserves the reference subject and gives the model enough scene detail to work.

## Default workflow
1. **Treat the reference image as authoritative** for subject identity if the user says "this exact boy/girl/person/object".
2. Build the prompt in this order:
   - subject identity
   - action / pose
   - environment / background
   - camera / composition
   - style / medium
   - quality / realism details
   - constraints / negatives
3. Keep the prompt **specific, visual, and concise**. Filler words hurt image models.
4. If the user wants the exact subject preserved, say so explicitly:
   - "Use the uploaded reference photo as the exact subject"
   - "Preserve face, hairstyle, age, clothing, and proportions"
5. For motion scenes, describe the mechanics plainly:
   - what the subject is doing
   - how the object is oriented
   - what is happening in the background
6. If the user asks to "find the right prompt online", use web research only if the style truly needs external best practices. Otherwise, use a strong internal prompt formula immediately.

## Prompt formula
A strong prompt usually looks like:

> Use the uploaded reference photo as the exact subject. [Subject] doing [action] in [environment]. [Motion / pose details]. [Composition / camera]. [Style / medium]. [Lighting / mood]. High detail, natural anatomy, sharp focus, clean background.

## Practical tips
- For portraits, mention **face, hair, age, clothing, expression**.
- For scenes with vehicles, mention **direction, surface, wheel contact, and perspective**.
- For stylized art, specify the medium: watercolor, oil, pencil sketch, poster, etc.
- If the user wants a faithful likeness, avoid broad style words that can override identity.
- If the user wants a dramatic scene, add motion, angle, and environment cues; models respond well to physical specifics.

## Output rules
- If the user only wants the image, generate it directly.
- If the user asks for a prompt, return the prompt itself, not an explanation essay.
- If a prompt is weak or ambiguous, improve it before generation rather than asking for a rewrite unless absolutely necessary.

## Linked reference
- See `references/prompt-cheatsheet.md` for a compact prompt pattern and a session-proven example.
