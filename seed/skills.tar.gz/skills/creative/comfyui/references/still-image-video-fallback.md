# Still-Image Video Fallback

Use this when the user asks for a video *from a single photo* and a full generative video pipeline is unnecessary or unavailable.

## Practical fallback
A clean, deterministic “Ken Burns” clip is often good enough:
- loop the image as the input frame
- add a slow zoom-in or pan
- render to MP4 with H.264 and `yuv420p`
- keep the aspect ratio even-numbered for encoder compatibility

## Example
```bash
ffmpeg -y -loop 1 -i input.jpg \
  -vf "zoompan=z='min(1.08,1+0.0006*on)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=144:s=1280x852:fps=24,format=yuv420p" \
  -t 6 -c:v libx264 -pix_fmt yuv420p output.mp4
```

## Notes
- If the source image height/width is odd, crop or scale to even dimensions before encoding.
- This produces motion from a still image; it is not the same as diffusion-based image-to-video.
- Good for quick previews, social snippets, and when the user mainly wants “some movement” from a photo.
- Do **not** use this fallback when the user explicitly wants the subject to start moving or the camera to follow action in-scene; that requires a real image-to-video workflow.
