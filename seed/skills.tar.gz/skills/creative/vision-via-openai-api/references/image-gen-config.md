# Конфигурация генерации изображений

Файл: `/root/.hermes/config.yaml`

## Секция image_gen

```yaml
image_gen:
  provider: openai
  model: gpt-image-2-medium
```

## Доступные модели

- `gpt-image-2` — базовая
- `gpt-image-2-medium` — средняя (текущая)
- `gpt-image-2-pro` — максимальное качество

## Изменение модели

```bash
sed -i 's/model: gpt-image-2-medium$/model: gpt-image-2-pro/' /root/.hermes/config.yaml
```

Файл config.yaml защищён от правки через patch/write_file, только через terminal (sed).
