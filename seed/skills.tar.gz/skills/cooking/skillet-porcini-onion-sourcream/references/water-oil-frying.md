# Water + oil frying technique

Discovered/validated during the 2026-06-05 session for skillet mushrooms.

## The method

1. Put chopped onion in a cold or medium-hot skillet.
2. Add water (100-150 ml for one onion) plus 1-2 tbsp olive oil directly into the water.
3. Cook on medium heat, stirring occasionally, until water evaporates (5-7 minutes).
4. Oil remains on the pan bottom after evaporation — now you have a lightly oiled hot surface.
5. Add mushrooms/other ingredients and fry as usual.

## Why it works

- Water prevents burning during the initial phase (no need for constant attention).
- As water evaporates, oil separates and coats the pan naturally.
- Result: fried taste with minimal oil — 1-2 tbsp total.
- Works for: onions, mushrooms, carrots, peppers — any vegetable that benefits from initial steaming then browning.

## Key pitfall

Don't cover the pan — you want water to evaporate. Covered = steamed, not fried.
