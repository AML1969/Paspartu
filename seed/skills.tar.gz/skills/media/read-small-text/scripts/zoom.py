#!/usr/bin/env python3
"""zoom.py — прочитать мелкое на фото: найти область → обрезать → усилить.

Зачем. 16.08.2026 vision_analyze уверенно прочитал на ярлыке кроссовка
`M BONDI 8 WIDE` там, где написано `M BONDI 9 WIDE`, и пользователю сказали,
что он купил поколение постарше. Цифра модели и буква ширины — самые мелкие
символы в кадре; по полному снимку 960x1280 они физически не читаются.
Проба 17.08.2026 показала: платные OCR (florence-2, GOT-OCR) справляются ХУЖЕ,
чем обычный vision по увеличенному фрагменту, а florence вдобавок выдумывает
текст, которого нет. Выигрыш даёт не модель, а предобработка.

Что делает скрипт:
    1. (опц.) просит fal-ai/moondream3-preview/detect найти область по описанию;
    2. режет её с запасом, увеличивает, при необходимости поворачивает и
       поднимает контраст;
    3. сохраняет файлы и печатает пути — дальше их смотрит vision_analyze.

Сам скрипт НИЧЕГО не распознаёт: он только готовит картинку для глаз модели.

Правила жизни:
    • ключ из FAL_KEY, а если песочница его вырезала — из .env профиля
      (та же логика, что в qwen.py);
    • без --find и без --box работает полностью локально, без сети и без денег;
    • detect стоит доли цента; если он не нашёл — не падаем, а режем сеткой;
    • ничего не удаляем и не перезаписываем в чужих папках: пишем в --out.

Примеры:
    zoom.py photo.jpg --find "size label"          # найти ярлык и увеличить
    zoom.py photo.jpg --find "stamp" --scale 8     # сильнее увеличить
    zoom.py photo.jpg --box 0.35,0.42,0.77,0.71    # координаты уже известны
    zoom.py photo.jpg --grid                       # без сети: 6 фрагментов внахлёст
    zoom.py photo.jpg --find "label" --rotate -63  # текст под углом
"""
import argparse
import base64
import json
import os
import sys
import urllib.error
import urllib.request

DETECT_EP = "https://fal.run/fal-ai/moondream3-preview/detect"
MAX_SIDE_UPLOAD = 2048          # detect'у больше не нужно, а трафик экономит
DEFAULT_SCALE = 6
DEFAULT_PAD = 0.04


def out(obj: dict, code: int = 0):
    print(json.dumps(obj, ensure_ascii=False, indent=2))
    sys.exit(code)


def fail(msg: str, **extra):
    d = {"error": msg}
    d.update(extra)
    out(d, 1)


def get_fal_key() -> str:
    """FAL_KEY из окружения; песочница терминала его вырезает → читаем .env профиля."""
    k = os.environ.get("FAL_KEY", "").strip()
    if k:
        return k
    home = os.environ.get("HERMES_HOME", "") or os.path.expanduser("~/.hermes")
    for envf in (os.path.join(home, ".env"), "/data/hermes/.env", "/root/.hermes/.env",
                 "/root/.hermes/profiles/paspartu-rm/.env"):
        try:
            with open(envf, encoding="utf-8") as f:
                for line in f:
                    if line.startswith("FAL_KEY="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
        except OSError:
            continue
    return ""


def data_uri(im) -> str:
    import io
    from PIL import Image
    w, h = im.size
    if max(w, h) > MAX_SIDE_UPLOAD:
        im = im.copy()
        im.thumbnail((MAX_SIDE_UPLOAD, MAX_SIDE_UPLOAD), Image.LANCZOS)
    if im.mode not in ("RGB", "L"):
        im = im.convert("RGB")
    buf = io.BytesIO()
    im.save(buf, format="JPEG", quality=92, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def detect(im, prompt: str, key: str):
    """Возвращает список боксов в долях 0..1 или (None, причина)."""
    body = json.dumps({"image_url": data_uri(im), "prompt": prompt}).encode()
    req = urllib.request.Request(
        DETECT_EP, data=body, method="POST",
        headers={"Authorization": "Key " + key, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            res = json.loads(r.read())
    except urllib.error.HTTPError as e:
        return None, "HTTP %s: %s" % (e.code, e.read().decode("utf-8", "replace")[:200])
    except Exception as e:                                    # noqa: BLE001
        return None, "%s: %s" % (type(e).__name__, e)
    objs = res.get("objects") or []
    boxes = []
    for o in objs:
        try:
            boxes.append((float(o["x_min"]), float(o["y_min"]),
                          float(o["x_max"]), float(o["y_max"])))
        except (KeyError, TypeError, ValueError):
            continue
    return (boxes or None), (None if boxes else "detect не нашёл «%s»" % prompt)


def enhance(im, scale: int, rotate: float, gray: bool):
    from PIL import Image, ImageOps
    if rotate:
        im = im.rotate(rotate, expand=True, resample=Image.BICUBIC)
    if scale > 1:
        im = im.resize((im.width * scale, im.height * scale), Image.LANCZOS)
    if gray:
        im = ImageOps.autocontrast(im.convert("L"))
    return im


def cut(im, box, pad):
    W, H = im.size
    x0, y0, x1, y1 = box
    return im.crop((max(0, int((x0 - pad) * W)), max(0, int((y0 - pad) * H)),
                    min(W, int((x1 + pad) * W)), min(H, int((y1 + pad) * H))))


def main():
    p = argparse.ArgumentParser(description="Увеличить мелкий фрагмент фото для чтения моделью")
    p.add_argument("image")
    p.add_argument("--find", help="что искать: 'size label', 'stamp', 'signature', 'price tag'")
    p.add_argument("--box", help="готовый бокс в долях: x0,y0,x1,y1 (0..1)")
    p.add_argument("--grid", action="store_true", help="без сети: нарезать сеткой 3x2 внахлёст")
    p.add_argument("--scale", type=int, default=DEFAULT_SCALE, help="во сколько раз увеличить")
    p.add_argument("--pad", type=float, default=DEFAULT_PAD, help="запас вокруг бокса, доли")
    p.add_argument("--strips", type=int, default=3,
                   help="на сколько горизонтальных полос дополнительно резать область (0 — не резать)")
    p.add_argument("--rotate", type=float, default=0,
                   help="повернуть на N градусов. ОСТОРОЖНО: на мелком тексте поворот "
                        "чаще ВРЕДИТ — проверено, из-за интерполяции цифра 9 читалась как 8. "
                        "Пробуй сначала без него")
    p.add_argument("--no-gray", action="store_true", help="не переводить в ч/б с автоконтрастом")
    p.add_argument("--out", default="", help="папка для результата")
    a = p.parse_args()

    try:
        from PIL import Image
    except ImportError:
        fail("нет Pillow — поставь: pip install pillow")

    if not os.path.isfile(a.image):
        fail("файл не найден: %s" % a.image)
    im = Image.open(a.image)
    W, H = im.size

    outdir = a.out or os.path.join(os.path.dirname(os.path.abspath(a.image)), "zoom")
    os.makedirs(outdir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(a.image))[0]
    gray = not a.no_gray

    boxes, note = [], None
    if a.box:
        try:
            v = [float(x) for x in a.box.split(",")]
            if len(v) != 4:
                raise ValueError
            boxes = [tuple(v)]
        except ValueError:
            fail("--box ждёт четыре числа 0..1 через запятую, напр. 0.35,0.42,0.77,0.71")
    elif a.find:
        key = get_fal_key()
        if not key:
            fail("нет FAL_KEY — задай его или используй --box / --grid")
        boxes, note = detect(im, a.find, key)
        if not boxes:
            note = (note or "не нашёл") + " → режу сеткой"
            a.grid = True

    files = []
    if boxes:
        for i, b in enumerate(boxes[:3], 1):
            whole = cut(im, b, a.pad)
            c = enhance(whole, a.scale, a.rotate, gray)
            fp = os.path.join(outdir, "%s_zoom%d.png" % (stem, i))
            c.save(fp)
            files.append({"file": fp, "box": [round(x, 4) for x in b],
                          "size": "%dx%d" % c.size, "kind": "вся область"})
            # Лесенка полос. Проверено 17.08.2026: на ярлыке кроссовка вся область
            # даже в 6x читается как «не читается», а узкая полоса с той же строкой —
            # уверенно и верно. Полосы бесплатны (локальный PIL), поэтому режем всегда.
            if a.strips > 1:
                w, h = whole.size
                ov = 0.12
                for s in range(a.strips):
                    y0 = max(0.0, s / a.strips - ov)
                    y1 = min(1.0, (s + 1) / a.strips + ov)
                    band = whole.crop((0, int(y0 * h), w, int(y1 * h)))
                    if band.height < 8:
                        continue
                    bc = enhance(band, a.scale, a.rotate, gray)
                    bp = os.path.join(outdir, "%s_zoom%d_s%d.png" % (stem, i, s + 1))
                    bc.save(bp)
                    files.append({"file": bp, "box": [round(x, 4) for x in b],
                                  "size": "%dx%d" % bc.size,
                                  "kind": "полоса %d из %d" % (s + 1, a.strips)})
    if a.grid:
        cols, rows, ov = 3, 2, 0.10
        for r in range(rows):
            for cc in range(cols):
                b = (max(0, cc / cols - ov), max(0, r / rows - ov),
                     min(1, (cc + 1) / cols + ov), min(1, (r + 1) / rows + ov))
                g = enhance(cut(im, b, 0), max(2, a.scale // 2), a.rotate, gray)
                fp = os.path.join(outdir, "%s_grid_r%dc%d.png" % (stem, r + 1, cc + 1))
                g.save(fp)
                files.append({"file": fp, "box": [round(x, 4) for x in b],
                              "size": "%dx%d" % g.size})

    if not files:
        fail("нечего резать: задай --find, --box или --grid")

    out({
        "source": a.image,
        "source_size": "%dx%d" % (W, H),
        "note": note,
        "files": files,
        "next": (
            "1) Посмотри через vision_analyze КАЖДЫЙ файл по отдельности — не только первый. "
            "Практика: «вся область» часто нечитаема, а нужная строка берётся с одной из полос.\n"
            "2) ПРАВИЛО КОНСЕНСУСА: считай прочитанным только то, что совпало минимум на ДВУХ "
            "файлах. Варианты умеют противоречить друг другу (проверено: одна полоса дала "
            "«BONDI 9 WIDE», другая — «CLIFTON 9 WIDE»). Совпало по цифре, разошлось по слову — "
            "значит цифре верь, слову нет.\n"
            "3) Если консенсуса нет — так и скажи пользователю: «не могу прочитать уверенно» "
            "и попроси снимок ближе. НЕ ДОГАДЫВАЙСЯ и не выбирай красивый вариант.\n"
            "4) Если на ярлыке есть числовой АРТИКУЛ — читай его: цифры устойчивее букв, "
            "и артикул проверяется поиском за один запрос (напр. HOKA 1162011 = Bondi 9, "
            "1162013 = Bondi 9 Wide). При расхождении названия и артикула верь артикулу."),
    })


if __name__ == "__main__":
    main()
