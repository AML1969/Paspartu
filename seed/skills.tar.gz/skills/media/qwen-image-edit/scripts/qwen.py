#!/usr/bin/env python3
"""qwen.py — картинки на fal.ai: генерация + редактирование, два движка.

Движки (11.09.2026):
    openai   OpenAI GPT-Image-2.5 Sunburst  (openai/gpt-image-2.5/sunburst/…) — люди, лица, любой текст
    qwen     Qwen-Image 2.0                 (fal-ai/qwen-image-2/…)            — всё остальное, дёшево и быстро
Какой движок — решает настройка бота в файле $HERMES_HOME/image_engine:
    openai → всегда Sunburst;  auto (или файла нет) → люди/текст → Sunburst, иначе Qwen;  qwen → всегда Qwen.
Флаг --engine перебивает настройку. Упал один движок — скрипт сам пробует второй.
Проба 11.09: Qwen на фото с людьми подменяет лица и путает кириллицу, Sunburst — нет.

Ниже — исходное описание Qwen-части (эндпоинты и правила не изменились).

Модель одна — Qwen-Image 2.0 (и её pro-вариант), четыре эндпоинта:
    generate            fal-ai/qwen-image-2/text-to-image      (текст → картинка)
    generate --pro      fal-ai/qwen-image-2/pro/text-to-image  (то же, максимум качества)
    edit                fal-ai/qwen-image-2/edit               (правка РЕАЛЬНЫХ фото, 1–3 шт)
    edit --pro          fal-ai/qwen-image-2/pro/edit

Что умеет edit (всё это — один и тот же вызов, разница только в prompt):
    • заменить/убрать объект, поменять фон, перекрасить, добавить надпись;
    • СЛИТЬ НЕСКОЛЬКО ФОТО: перенести человека/предмет с одного кадра в другой,
      собрать общий кадр из отдельных снимков (--image A --image B [--image C]);
    • сменить свет/сцену/ракурс, сохранив людей и композицию.

Правила жизни:
    • фото пользователя — ИСХОДНИК: если фото есть, правим его, а не рисуем новое;
    • локальные файлы жмутся сами (Pillow, ≤2048px) — внешний `convert` не нужен;
    • ключ из FAL_KEY, а если песочница его вырезала — из .env профиля;
    • результат скачивается локально, наружу идёт поле telegram=MEDIA:<путь>
      (ссылки fal.media Telegram не грузит — они не возвращаются никогда).
"""
import argparse, base64, io, json, mimetypes, os, re, sys, time, urllib.error, urllib.request

BASE = "https://fal.run/"
EP = {
    ("generate", False): "fal-ai/qwen-image-2/text-to-image",
    ("generate", True):  "fal-ai/qwen-image-2/pro/text-to-image",
    ("edit", False):     "fal-ai/qwen-image-2/edit",
    ("edit", True):      "fal-ai/qwen-image-2/pro/edit",
}
# Схема Qwen-Image 2.0 (fal openapi, 14.07.2026) знает РОВНО эти поля. Лишнее → 422.
FIELDS = {"prompt", "image_urls", "image_size", "num_images", "output_format"}
SIZES = ("square_hd", "square", "portrait_4_3", "portrait_16_9",
         "landscape_4_3", "landscape_16_9")
MAX_BYTES, MAX_SIDE = 12 * 1024 * 1024, 2048

# OpenAI GPT-Image-2.5 на fal (schema 11.09.2026). Работает на том же FAL_KEY.
OA_EP = {"generate": "openai/gpt-image-2.5/sunburst/text-to-image",
         "edit":     "openai/gpt-image-2.5/sunburst/edit"}
OA_FIELDS = {"prompt", "image_urls", "image_size", "num_images", "output_format", "quality"}
OA_MAX_IMAGES, QWEN_MAX_IMAGES = 16, 3
QUALITIES = ("low", "medium", "high", "xhigh", "max", "auto")
DEADLINE_S = 165          # у терминала бота лимит 180 с — всё должно успеть внутри
ENGINES = ("auto", "openai", "qwen")

TEXT_RE = re.compile(r"[«»“”„]|надпис|текст|вывеск|постер|плакат|афиш|открытк|логотип|подпис|баннер|обложк|"
                     r"табличк|слоган|меню\b|\bsign\b|\btext\b|poster|lettering|caption|logo|banner|headline", re.I)
PEOPLE_RE = re.compile(r"люд|человек|мужчин|женщин|девушк|девочк|парн|парен|мальчик|ребён|ребен|дет[иьея]|малыш|"
                       r"\bлиц[оау]?\b|портрет|семь[яиюе]|бабушк|дедушк|\bмам[аыу]\b|\bпап[аыу]\b|\bжен[аыу]\b|\bмуж\b|"
                       r"\bсын|\bдоч|друз|селфи|силуэт|\bperson|people|\bman\b|\bmen\b|woman|women|girl|\bboys?\b|"
                       r"child|\bkids?\b|\bfaces?\b|portrait|couple|family|selfie|crowd|silhouette", re.I)
NO_PEOPLE_RE = re.compile(r"(людей|человека|лиц)\s+нет|нет\s+(людей|человека|лиц)|без\s+людей|no\s+(people|person|humans?)", re.I)


def engine_setting():
    """Настройка бота: файл image_engine в HERMES_HOME. Нет файла → auto."""
    home = os.environ.get("HERMES_HOME", "") or os.path.expanduser("~/.hermes")
    for f in (os.path.join(home, "image_engine"), "/data/hermes/image_engine"):
        try:
            v = open(f, encoding="utf-8").read().strip().lower()
            return (v if v in ENGINES else "auto"), f
        except OSError:
            continue
    return "auto", "(файла нет)"


def detect(raw, prompt, descr, llm):
    """Люди/текст. Есть оценка DeepSeek → берём её, а людей дополнительно ловим по vision-описаниям
    исходников (надёжно). Оценки нет (ручной --prompt, сбой) → по словам запроса.
    Сам собранный промпт по словам НЕ проверяем: там бывает «No text», «keep every person…»."""
    seen = NO_PEOPLE_RE.sub(" ", " ".join(descr or []))
    in_photo = bool(PEOPLE_RE.search(seen))
    if llm is not None:
        return {"people": bool(llm.get("people")) or in_photo, "text": bool(llm.get("text"))}
    req = " ".join(x for x in (raw or "", prompt or "") if x)
    req = re.sub(r"(?i)keep every person.*$", "", req)   # хвост KEEP-фразы — не сигнал
    return {"people": bool(PEOPLE_RE.search(req)) or in_photo, "text": bool(TEXT_RE.search(req))}


def choose_engine(forced, setting, n_images, flags):
    if forced in ("openai", "qwen"):
        return forced, "флаг --engine " + forced
    if setting in ("openai", "qwen"):
        return setting, "настройка бота: " + setting
    if n_images > QWEN_MAX_IMAGES:
        return "openai", "больше %d фото" % QWEN_MAX_IMAGES
    if flags.get("people"):
        return "openai", "на картинке люди"
    if flags.get("text"):
        return "openai", "на картинке текст"
    return "qwen", "без людей и текста"


def fail(msg, **extra):
    out = {"error": msg}
    out.update(extra)
    print(json.dumps(out, ensure_ascii=False))
    sys.exit(1)


def get_fal_key() -> str:
    """FAL_KEY из окружения; песочница терминала его вырезает → читаем .env профиля сами."""
    k = os.environ.get("FAL_KEY", "").strip()
    if k:
        return k
    home = os.environ.get("HERMES_HOME", "") or os.path.expanduser("~/.hermes")
    for envf in (os.path.join(home, ".env"), "/data/hermes/.env", "/root/.hermes/.env"):
        try:
            with open(envf, encoding="utf-8") as f:
                for line in f:
                    if line.startswith("FAL_KEY="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
        except OSError:
            continue
    return ""


def data_uri(path: str) -> str:
    raw = open(path, "rb").read()
    mime = mimetypes.guess_type(path)[0] or "image/png"
    small = len(raw) <= MAX_BYTES
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(raw))
        if small and max(im.size) <= MAX_SIDE:
            return "data:%s;base64,%s" % (mime, base64.b64encode(raw).decode())
        im.thumbnail((MAX_SIDE, MAX_SIDE))
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=92, optimize=True)
        return "data:image/jpeg;base64,%s" % base64.b64encode(buf.getvalue()).decode()
    except ImportError:
        if not small:
            fail("фото %.1f МБ, а Pillow не установлен — уменьши файл" % (len(raw) / 1048576))
        return "data:%s;base64,%s" % (mime, base64.b64encode(raw).decode())
    except Exception as e:  # noqa: BLE001
        fail("не смог прочитать/ужать %s: %s" % (path, e))


def to_url(img: str) -> str:
    img = img.strip()
    if img.startswith(("http://", "https://")):
        return img
    if not os.path.isfile(img):
        fail("файл не найден: %s" % img)
    return data_uri(img)


# ── Сборка промпта: vision-описание фото → (опц. факты из веба) → промпт по правилам Qwen ──
KEEP = ("Keep every person's face, identity, expression, hairstyle, body and clothing EXACTLY "
        "unchanged — same people. Do not add, remove or invent anything that was not requested.")

RULEBOOK = """Ты — промпт-инженер для моделей генерации и редактирования картинок (Qwen-Image 2.0 и OpenAI GPT-Image-2.5).
Тебе дают: (1) дословный запрос пользователя (обычно по-русски), (2) описания его исходных фото,
(3) иногда факты из интернета. Верни РОВНО ОДИН JSON-объект — и больше ничего (без markdown, без пояснений):
{"prompt": "<промпт>", "people": true или false, "text": true или false}

people = true, если на исходных фото есть люди ИЛИ на результате должны быть люди (человек, лицо, портрет, пара,
семья, толпа, силуэт человека). text = true, если на результате должен быть читаемый текст: надпись, вывеска,
подпись, постер/афиша/открытка/меню с текстом, логотип с буквами, даты.

Правила промпта:
- только английский язык; НО текст, который должен появиться НА картинке, приводи ДОСЛОВНО на языке пользователя
  в двойных кавычках — не переводи и не транслитерируй;
- начинай с глагола действия: Replace / Remove / Add / Change / Take ... and place ...;
- если исходных фото несколько — явно называй их роли: "image 1", "image 2", "image 3"
  (например: take the person from image 1 and place them into the scene of image 2);
- ровно одно смысловое изменение; не выдумывай деталей, которых не просили;
- сохраняй суть запроса пользователя целиком, ничего не теряй;
- при редактировании реальных фото ОБЯЗАТЕЛЬНО добавь в конец фразу сохранения:
  "%s";
- для фотореализма пиши: photorealistic photo, genuine camera shot, natural lighting, sharp focus.
  НИКОГДА не пиши illustration / artistic / painterly, если пользователь не просил рисунок;
- 1-4 предложения, плотно, без воды.""" % KEEP


def _http_json(url, payload, headers, timeout=120):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json", **headers})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _env(name):
    v = os.environ.get(name, "").strip()
    if v:
        return v
    home = os.environ.get("HERMES_HOME", "") or os.path.expanduser("~/.hermes")
    for envf in (os.path.join(home, ".env"), "/data/hermes/.env", "/root/.hermes/.env"):
        try:
            with open(envf, encoding="utf-8") as f:
                for line in f:
                    if line.startswith(name + "="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
        except OSError:
            continue
    return ""


def describe_images(urls):
    """Vision-описание исходников (OpenAI gpt-5.4 — та же aux-роль, что у бота).
    Фото описываются ПАРАЛЛЕЛЬНО: 3 снимка не должны складываться в 60 секунд ожидания."""
    key = _env("OPENAI_API_KEY")
    if not key:
        return []

    def one(item):
        n, u = item
        try:
            r = _http_json(
                "https://api.openai.com/v1/chat/completions",
                {"model": os.environ.get("QWEN_VISION_MODEL", "gpt-5.4"),
                 "messages": [{"role": "user", "content": [
                     {"type": "text", "text": "Опиши это фото для промпт-инженера: кто/что на нём "
                      "(люди, их число, лица, одежда, поза), фон, освещение, ракурс. 2-3 предложения, по-русски."},
                     {"type": "image_url", "image_url": {"url": u}}]}]},
                {"Authorization": "Bearer " + key}, timeout=90)
            return "image %d: %s" % (n, r["choices"][0]["message"]["content"].strip())
        except Exception as e:  # noqa: BLE001 — vision необязателен, промпт соберём и без него
            return "image %d: (описать не удалось: %s)" % (n, str(e)[:80])

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=3) as pool:
        return list(pool.map(one, enumerate(urls, 1)))


def research(query):
    """Факты из интернета для промпта (Perplexity sonar) — если агент попросил."""
    key = _env("PERPLEXITY_API_KEY")
    if not key or not query:
        return ""
    try:
        r = _http_json("https://api.perplexity.ai/chat/completions",
                       {"model": "sonar", "messages": [{"role": "user", "content":
                        "Кратко и фактически (3-5 предложений), как это выглядит: " + query}]},
                       {"Authorization": "Bearer " + key}, timeout=60)
        return r["choices"][0]["message"]["content"].strip()
    except Exception:  # noqa: BLE001
        return ""


def _parse_builder(txt):
    """JSON от DeepSeek → (prompt, flags). Не JSON — весь текст считаем промптом, flags=None."""
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", txt.strip())
    m = re.search(r"\{.*\}", t, re.S)
    if m:
        try:
            d = json.loads(m.group(0))
            p = str(d.get("prompt", "")).strip()
            if p:
                return p, {"people": bool(d.get("people")), "text": bool(d.get("text"))}
        except Exception:  # noqa: BLE001
            pass
    if len(t) > 1 and t[0] == t[-1] == '"' and t.count('"') == 2:
        t = t[1:-1]   # срезаем только обёртку целиком, не кавычку у текста в конце промпта
    return t, None


def build_prompt(raw, img_descr, facts, editing):
    """Промпт собирает текстовая модель (DeepSeek), она же оценивает люди/текст. → (prompt, src, flags|None)"""
    key = _env("DEEPSEEK_API_KEY")
    parts = ["Запрос пользователя (дословно): " + raw]
    if img_descr:
        parts.append("Исходные фото:\n" + "\n".join(img_descr))
    if facts:
        parts.append("Факты из интернета:\n" + facts)
    parts.append("Режим: " + ("редактирование существующих фото" if editing else "генерация с нуля"))
    if not key:
        return (raw + (" " + KEEP if editing else ""), "raw-fallback", None)
    for model in (os.environ.get("QWEN_PROMPT_MODEL", "deepseek-v4-pro"), "deepseek-chat"):
        try:
            r = _http_json("https://api.deepseek.com/v1/chat/completions",
                           {"model": model, "temperature": 0.3,
                            "messages": [{"role": "system", "content": RULEBOOK},
                                         {"role": "user", "content": "\n\n".join(parts)}]},
                           {"Authorization": "Bearer " + key}, timeout=120)
            p, flags = _parse_builder(r["choices"][0]["message"]["content"])
            if not p:
                continue
            if editing and "unchanged" not in p.lower():
                p += " " + KEEP
            return (p, "auto:" + model, flags)
        except Exception:  # noqa: BLE001 — пробуем следующую модель
            continue
    return (raw + (" " + KEEP if editing else ""), "raw-fallback", None)


def _size_value(size):
    if not size:
        return None
    if size in SIZES:
        return size
    if "x" in size.lower():
        try:
            w, h = (int(v) for v in size.lower().split("x", 1))
            return {"width": w, "height": h}
        except ValueError:
            pass
    fail("--size: %s или ШИРИНАxВЫСОТА (числа), напр. 1024x1536" % "|".join(SIZES))


def _request(engine, a, prompt, img_urls, pro):
    """→ (endpoint, body) для выбранного движка. Каждой схеме — только её поля (лишнее = 422)."""
    body = {"prompt": prompt}
    if img_urls:
        body["image_urls"] = img_urls
    if a.num != 1:
        body["num_images"] = max(1, min(4, a.num))
    if a.fmt:
        body["output_format"] = a.fmt
    sz = _size_value(a.size)
    if sz:
        body["image_size"] = sz
    if engine == "openai":
        body["quality"] = a.quality
        return OA_EP[a.task], {k: v for k, v in body.items() if k in OA_FIELDS}
    return EP[(a.task, pro)], {k: v for k, v in body.items() if k in FIELDS}


def _call(ep, body, key, timeout):
    req = urllib.request.Request(
        BASE + ep, data=json.dumps(body).encode(),
        headers={"Authorization": "Key " + key, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            out = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return None, "fal HTTP %s: %s" % (e.code, re.sub(r"https?://\S+", "<url>", e.read().decode()[:300]))
    except Exception as e:  # noqa: BLE001
        return None, "запрос не прошёл: %s" % e
    items = out.get("images") or []
    if not items or not items[0].get("url"):
        # ВАЖНО: CDN-ссылки fal наружу не отдаём — Telegram их не грузит. Вырезаем любые URL.
        return None, "в ответе fal нет картинок: " + re.sub(r"https?://\S+", "<url скрыт>", str(out))[:300]
    return items, ""


def main():
    t_start = time.time()
    ap = argparse.ArgumentParser(
        description="Картинки на fal: OpenAI GPT-Image-2.5 Sunburst (люди, текст) + Qwen-Image 2.0 (остальное)",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    ap.add_argument("task", choices=["generate", "edit"])
    ap.add_argument("--image", action="append", default=[],
                    help="исходное фото: абсолютный путь или URL. Повторяется (Qwen до 3, Sunburst до 16) — "
                         "слияние кадров / перенос объекта. Обязателен для edit")
    ap.add_argument("--prompt", help="готовая инструкция НА АНГЛИЙСКОМ (если промпт уже собран)")
    ap.add_argument("--raw", help="ПРЕДПОЧТИТЕЛЬНО: дословный запрос пользователя (можно по-русски). "
                                  "Скрипт сам посмотрит фото (vision), соберёт промпт, выберет движок "
                                  "и отправит всё вместе с фотографиями")
    ap.add_argument("--context", default="", help="доп. факты для промпта (что ты уже нашёл/знаешь)")
    ap.add_argument("--research", dest="research_q", default="",
                    help="что уточнить в интернете перед сборкой промпта (Perplexity)")
    ap.add_argument("--dry-run", action="store_true",
                    help="только собрать промпт и выбрать движок — показать, не рисовать")
    ap.add_argument("--engine", default="", choices=("",) + ENGINES,
                    help="перебить настройку бота: openai | qwen | auto. Только если пользователь прямо назвал модель")
    ap.add_argument("--pro", action="store_true", help="для движка qwen: pro-вариант Qwen 2.0")
    ap.add_argument("--quality", default="high", choices=QUALITIES, help="для движка openai (по умолчанию high)")
    ap.add_argument("--size", default="", help="|".join(SIZES) + " или ШИРИНАxВЫСОТА")
    ap.add_argument("--num", type=int, default=1, help="число вариантов (1..4)")
    ap.add_argument("--format", dest="fmt", default="", choices=["", "png", "jpeg"])
    a = ap.parse_args()

    key = get_fal_key()
    if not key:
        fail("FAL_KEY не найден: ни в окружении, ни в .env профиля")
    if not a.prompt and not a.raw:
        fail("нужен --raw «дословный запрос пользователя» (скрипт сам соберёт промпт) "
             "или готовый --prompt на английском")
    if a.task == "edit" and not a.image:
        fail("edit требует хотя бы одно --image. Фото пользователя — исходник, "
             "а не вдохновение: генерировать заново вместо правки нельзя")
    if a.task == "generate" and a.image:
        fail("у generate не бывает входных фото. Раз фото есть — это задача edit")
    if len(a.image) > OA_MAX_IMAGES:
        fail("максимум %d фото на вход" % OA_MAX_IMAGES)
    if a.engine == "qwen" and len(a.image) > QWEN_MAX_IMAGES:
        fail("Qwen-Image 2.0 принимает максимум 3 фото — убери --engine qwen, Sunburst берёт до 16")

    img_urls = [to_url(i) for i in a.image]

    # ── конвейер промпта: фото → vision → (веб-факты) → промпт + оценка «люди/текст» ──
    t_build = time.time()
    flags = None
    if a.prompt:
        prompt = a.prompt
        if img_urls and "unchanged" not in prompt.lower():
            prompt += " " + KEEP   # иначе модель подменяет людей (жалоба 14.07)
        src, descr = "manual", []
    else:
        descr = describe_images(img_urls) if img_urls else []
        facts = "\n".join(x for x in (a.context, research(a.research_q)) if x)
        prompt, src, flags = build_prompt(a.raw, descr, facts, bool(img_urls))
    build_s = round(time.time() - t_build, 1)

    route_flags = detect(a.raw, prompt, descr, flags)
    setting, setting_src = engine_setting()
    engine, why = choose_engine(a.engine, setting, len(img_urls), route_flags)

    if a.dry_run:
        print(json.dumps({"engine": engine, "route": why, "setting": setting, "setting_file": setting_src,
                          "flags": route_flags, "flags_llm": flags, "prompt": prompt, "prompt_source": src,
                          "vision": descr, "build_s": build_s}, ensure_ascii=False))
        return

    # ── вызов: основной движок, при ошибке — второй (если успеваем в лимит терминала) ──
    order = [engine] + [e for e in ("openai", "qwen") if e != engine]
    attempts, items, ep, used, t0 = [], None, "", "", time.time()
    for i, eng in enumerate(order):
        left = DEADLINE_S - (time.time() - t_start)
        if i > 0 and (left < 35 or (eng == "qwen" and len(img_urls) > QWEN_MAX_IMAGES)):
            break
        ep, body = _request(eng, a, prompt, img_urls, pro=(a.pro or i > 0))
        t0 = time.time()
        items, err = _call(ep, body, key, timeout=max(20, min(140 if eng == "openai" else 90, left - 5)))
        if items:
            used = eng
            break
        attempts.append({"engine": eng, "endpoint": ep, "error": err, "s": round(time.time() - t0, 1)})
    if not items:
        fail("картинка не получилась ни одним движком", attempts=attempts)

    home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    dstdir = os.path.join(home, "cache", "images")
    os.makedirs(dstdir, exist_ok=True)
    tag = "sunburst" if used == "openai" else "qwen"
    paths = []
    for n, it in enumerate(items):
        url = it["url"]
        ext = ".png" if ".png" in url.split("?")[0].lower() else ".jpg"
        dst = os.path.join(dstdir, "%s_%s_%d%s%s" % (
            tag, a.task, int(time.time()), "" if n == 0 else "_%d" % n, ext))
        urllib.request.urlretrieve(url, dst)
        paths.append(dst)

    res = {
        "image": paths[0],
        "telegram": "\n".join("MEDIA:" + p for p in paths),   # именно \n: через пробел гейтвей склеит пути и не отправит ничего
        "note": "вставь строку из поля telegram в ответ КАК ЕСТЬ; ссылки fal.media Telegram не грузит",
        "engine": "OpenAI GPT-Image-2.5 Sunburst" if used == "openai" else "Qwen-Image 2.0" + (" Pro" if "/pro/" in ep else ""),
        "route": why,
        "endpoint": ep,
        "inputs": len(a.image),
        "prompt_used": prompt,
        "prompt_source": src,
        "build_s": build_s,
        "elapsed_s": round(time.time() - t0, 1),
    }
    if attempts:
        res["fallback"] = attempts
    if len(paths) > 1:
        res["images"] = paths
    print(json.dumps(res, ensure_ascii=False))


if __name__ == "__main__":
    main()
