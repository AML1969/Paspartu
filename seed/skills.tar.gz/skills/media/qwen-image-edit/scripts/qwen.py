#!/usr/bin/env python3
"""qwen.py — полный доступ к Qwen-Image 2.0 на fal.ai (генерация + редактирование).

Модель одна — Qwen-Image 2.0 (и её pro-вариант), четыре эндпоинта:
    generate            fal-ai/qwen-image-2/text-to-image      (текст → картинка)
    generate --pro      fal-ai/qwen-image-2/pro/text-to-image  (то же, максимум качества)
    edit                fal-ai/qwen-image-2/edit               (правка РЕАЛЬНЫХ фото, 1–3 шт)
    edit --pro          fal-ai/qwen-image-2/pro/edit

Что умеет edit (всё это — один и тот же вызов, разница только в prompt):
    • заменить/убрать объект, поменять фон, перекрасить, добавить надпись;
    • СЛИТЬ НЕСКОЛЬКО ФОТО: перенести человека/предмет с одного кадра в другой,
      собрать общий кадр из отдельных снимков (--image A --image B [--image C]);
    • сменить свет/сцену/ракурс, сохранив людей и композицию.

Правила жизни:
    • фото пользователя — ИСХОДНИК: если фото есть, правим его, а не рисуем новое;
    • локальные файлы жмутся сами (Pillow, ≤2048px) — внешний `convert` не нужен;
    • ключ из FAL_KEY, а если песочница его вырезала — из .env профиля;
    • результат скачивается локально, наружу идёт поле telegram=MEDIA:<путь>
      (ссылки fal.media Telegram не грузит — они не возвращаются никогда).
"""
import argparse, base64, io, json, mimetypes, os, re, sys, time, urllib.error, urllib.request

BASE = "https://fal.run/"
EP = {
    ("generate", False): "fal-ai/qwen-image-2/text-to-image",
    ("generate", True):  "fal-ai/qwen-image-2/pro/text-to-image",
    ("edit", False):     "fal-ai/qwen-image-2/edit",
    ("edit", True):      "fal-ai/qwen-image-2/pro/edit",
}
# Схема Qwen-Image 2.0 (fal openapi, 14.07.2026) знает РОВНО эти поля. Лишнее → 422.
FIELDS = {"prompt", "image_urls", "image_size", "num_images", "output_format"}
SIZES = ("square_hd", "square", "portrait_4_3", "portrait_16_9",
         "landscape_4_3", "landscape_16_9")
MAX_BYTES, MAX_SIDE = 12 * 1024 * 1024, 2048


def fail(msg, **extra):
    out = {"error": msg}
    out.update(extra)
    print(json.dumps(out, ensure_ascii=False))
    sys.exit(1)


def get_fal_key() -> str:
    """FAL_KEY из окружения; песочница терминала его вырезает → читаем .env профиля сами."""
    k = os.environ.get("FAL_KEY", "").strip()
    if k:
        return k
    home = os.environ.get("HERMES_HOME", "") or os.path.expanduser("~/.hermes")
    for envf in (os.path.join(home, ".env"), "/data/hermes/.env", "/root/.hermes/.env"):
        try:
            with open(envf, encoding="utf-8") as f:
                for line in f:
                    if line.startswith("FAL_KEY="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
        except OSError:
            continue
    return ""


def data_uri(path: str) -> str:
    raw = open(path, "rb").read()
    mime = mimetypes.guess_type(path)[0] or "image/png"
    small = len(raw) <= MAX_BYTES
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(raw))
        if small and max(im.size) <= MAX_SIDE:
            return "data:%s;base64,%s" % (mime, base64.b64encode(raw).decode())
        im.thumbnail((MAX_SIDE, MAX_SIDE))
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=92, optimize=True)
        return "data:image/jpeg;base64,%s" % base64.b64encode(buf.getvalue()).decode()
    except ImportError:
        if not small:
            fail("фото %.1f МБ, а Pillow не установлен — уменьши файл" % (len(raw) / 1048576))
        return "data:%s;base64,%s" % (mime, base64.b64encode(raw).decode())
    except Exception as e:  # noqa: BLE001
        fail("не смог прочитать/ужать %s: %s" % (path, e))


def to_url(img: str) -> str:
    img = img.strip()
    if img.startswith(("http://", "https://")):
        return img
    if not os.path.isfile(img):
        fail("файл не найден: %s" % img)
    return data_uri(img)


# ── Сборка промпта: vision-описание фото → (опц. факты из веба) → промпт по правилам Qwen ──
KEEP = ("Keep every person's face, identity, expression, hairstyle, body and clothing EXACTLY "
        "unchanged — same people. Do not add, remove or invent anything that was not requested.")

RULEBOOK = """Ты — промпт-инженер для модели Qwen-Image 2.0 (генерация и редактирование картинок).
Тебе дают: (1) дословный запрос пользователя (обычно по-русски), (2) описания его исходных фото,
(3) иногда факты из интернета. Верни РОВНО ОДИН промпт для Qwen — и больше ничего: без пояснений,
без кавычек, без markdown.

Правила промпта:
- только английский язык;
- начинай с глагола действия: Replace / Remove / Add / Change / Take ... and place ...;
- если исходных фото несколько — явно называй их роли: "image 1", "image 2", "image 3"
  (например: take the person from image 1 and place them into the scene of image 2);
- ровно одно смысловое изменение; не выдумывай деталей, которых не просили;
- сохраняй суть запроса пользователя целиком, ничего не теряй;
- при редактировании реальных фото ОБЯЗАТЕЛЬНО добавь в конец фразу сохранения:
  "%s";
- для фотореализма пиши: photorealistic photo, genuine camera shot, natural lighting, sharp focus.
  НИКОГДА не пиши illustration / artistic / painterly, если пользователь не просил рисунок;
- 1-4 предложения, плотно, без воды.""" % KEEP


def _http_json(url, payload, headers, timeout=120):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json", **headers})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _env(name):
    v = os.environ.get(name, "").strip()
    if v:
        return v
    home = os.environ.get("HERMES_HOME", "") or os.path.expanduser("~/.hermes")
    for envf in (os.path.join(home, ".env"), "/data/hermes/.env", "/root/.hermes/.env"):
        try:
            with open(envf, encoding="utf-8") as f:
                for line in f:
                    if line.startswith(name + "="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
        except OSError:
            continue
    return ""


def describe_images(urls):
    """Vision-описание исходников (OpenAI gpt-5.4 — та же aux-роль, что у бота).
    Фото описываются ПАРАЛЛЕЛЬНО: 3 снимка не должны складываться в 60 секунд ожидания."""
    key = _env("OPENAI_API_KEY")
    if not key:
        return []

    def one(item):
        n, u = item
        try:
            r = _http_json(
                "https://api.openai.com/v1/chat/completions",
                {"model": os.environ.get("QWEN_VISION_MODEL", "gpt-5.4"),
                 "messages": [{"role": "user", "content": [
                     {"type": "text", "text": "Опиши это фото для промпт-инженера: кто/что на нём "
                      "(люди, их число, лица, одежда, поза), фон, освещение, ракурс. 2-3 предложения, по-русски."},
                     {"type": "image_url", "image_url": {"url": u}}]}]},
                {"Authorization": "Bearer " + key}, timeout=90)
            return "image %d: %s" % (n, r["choices"][0]["message"]["content"].strip())
        except Exception as e:  # noqa: BLE001 — vision необязателен, промпт соберём и без него
            return "image %d: (описать не удалось: %s)" % (n, str(e)[:80])

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=3) as pool:
        return list(pool.map(one, enumerate(urls, 1)))


def research(query):
    """Факты из интернета для промпта (Perplexity sonar) — если агент попросил."""
    key = _env("PERPLEXITY_API_KEY")
    if not key or not query:
        return ""
    try:
        r = _http_json("https://api.perplexity.ai/chat/completions",
                       {"model": "sonar", "messages": [{"role": "user", "content":
                        "Кратко и фактически (3-5 предложений), как это выглядит: " + query}]},
                       {"Authorization": "Bearer " + key}, timeout=60)
        return r["choices"][0]["message"]["content"].strip()
    except Exception:  # noqa: BLE001
        return ""


def build_prompt(raw, img_descr, facts, editing):
    """Промпт по правилам Qwen — собирает текстовая модель (DeepSeek), не пользователь."""
    key = _env("DEEPSEEK_API_KEY")
    parts = ["Запрос пользователя (дословно): " + raw]
    if img_descr:
        parts.append("Исходные фото:\n" + "\n".join(img_descr))
    if facts:
        parts.append("Факты из интернета:\n" + facts)
    parts.append("Режим: " + ("редактирование существующих фото" if editing else "генерация с нуля"))
    if not key:
        return (raw + (" " + KEEP if editing else ""), "raw-fallback")
    for model in (os.environ.get("QWEN_PROMPT_MODEL", "deepseek-v4-pro"), "deepseek-chat"):
        try:
            r = _http_json("https://api.deepseek.com/v1/chat/completions",
                           {"model": model, "temperature": 0.3,
                            "messages": [{"role": "system", "content": RULEBOOK},
                                         {"role": "user", "content": "\n\n".join(parts)}]},
                           {"Authorization": "Bearer " + key}, timeout=120)
            p = r["choices"][0]["message"]["content"].strip().strip('"')
            if editing and "unchanged" not in p.lower():
                p += " " + KEEP
            return (p, "auto:" + model)
        except Exception:  # noqa: BLE001 — пробуем следующую модель
            continue
    return (raw + (" " + KEEP if editing else ""), "raw-fallback")


def main():
    ap = argparse.ArgumentParser(
        description="Qwen-Image 2.0 (fal): генерация и редактирование реальных фото",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    ap.add_argument("task", choices=["generate", "edit"])
    ap.add_argument("--image", action="append", default=[],
                    help="исходное фото: абсолютный путь или URL. Повторяется (до 3) — "
                         "слияние кадров / перенос объекта. Обязателен для edit")
    ap.add_argument("--prompt", help="готовая инструкция НА АНГЛИЙСКОМ (если промпт уже собран)")
    ap.add_argument("--raw", help="ПРЕДПОЧТИТЕЛЬНО: дословный запрос пользователя (можно по-русски). "
                                  "Скрипт сам посмотрит фото (vision), соберёт промпт по правилам "
                                  "Qwen и отправит его вместе с фотографиями")
    ap.add_argument("--context", default="", help="доп. факты для промпта (что ты уже нашёл/знаешь)")
    ap.add_argument("--research", dest="research_q", default="",
                    help="что уточнить в интернете перед сборкой промпта (Perplexity)")
    ap.add_argument("--dry-run", action="store_true", help="только собрать промпт и показать, не рисовать")
    ap.add_argument("--pro", action="store_true", help="pro-вариант Qwen 2.0 (дороже, качественнее)")
    ap.add_argument("--size", default="", help="|".join(SIZES) + " или ШИРИНАxВЫСОТА")
    ap.add_argument("--num", type=int, default=1, help="число вариантов (1..4)")
    ap.add_argument("--format", dest="fmt", default="", choices=["", "png", "jpeg"])
    a = ap.parse_args()

    key = get_fal_key()
    if not key:
        fail("FAL_KEY не найден: ни в окружении, ни в .env профиля")

    if not a.prompt and not a.raw:
        fail("нужен --raw «дословный запрос пользователя» (скрипт сам соберёт промпт) "
             "или готовый --prompt на английском")
    if a.task == "edit" and not a.image:
        fail("edit требует хотя бы одно --image. Фото пользователя — исходник, "
             "а не вдохновение: генерировать заново вместо правки нельзя")
    if a.task == "generate" and a.image:
        fail("у generate не бывает входных фото. Раз фото есть — это задача edit")
    if len(a.image) > 3:
        fail("Qwen-Image 2.0 принимает максимум 3 фото на вход")

    # исходники → data-URI (ими же кормим vision, чтобы промпт собирался ПО ФОТО)
    img_urls = [to_url(i) for i in a.image]

    # ── конвейер промпта: фото → vision → (веб-факты) → правила Qwen → промпт ──
    t_build = time.time()
    if a.prompt:
        # ручной промпт: keep-фразу для правки фото добавляем принудительно — иначе
        # модель Qwen подменяет людей (главная жалоба 14.07), а дисциплины не хватает
        prompt = a.prompt
        if img_urls and "unchanged" not in prompt.lower():
            prompt += " " + KEEP
        src, descr = "manual", []
    else:
        descr = describe_images(img_urls) if img_urls else []
        facts = "\n".join(x for x in (a.context, research(a.research_q)) if x)
        prompt, src = build_prompt(a.raw, descr, facts, bool(img_urls))
    build_s = round(time.time() - t_build, 1)

    if a.dry_run:
        print(json.dumps({"prompt": prompt, "prompt_source": src, "vision": descr,
                          "build_s": build_s}, ensure_ascii=False))
        return

    body = {"prompt": prompt}
    if img_urls:
        body["image_urls"] = img_urls
    if a.num != 1:
        body["num_images"] = max(1, min(4, a.num))
    if a.fmt:
        body["output_format"] = a.fmt
    if a.size:
        if a.size in SIZES:
            body["image_size"] = a.size
        elif "x" in a.size.lower():
            try:
                w, h = (int(v) for v in a.size.lower().split("x", 1))
            except ValueError:
                fail("--size: %s или ШИРИНАxВЫСОТА (числа), напр. 1024x1536" % "|".join(SIZES))
            body["image_size"] = {"width": w, "height": h}
        else:
            fail("--size: %s или ШИРИНАxВЫСОТА" % "|".join(SIZES))
    body = {k: v for k, v in body.items() if k in FIELDS}

    ep = EP[(a.task, a.pro)]
    req = urllib.request.Request(
        BASE + ep, data=json.dumps(body).encode(),
        headers={"Authorization": "Key " + key, "Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=900) as r:
            out = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        fail("fal HTTP %s: %s" % (e.code, e.read().decode()[:300]), endpoint=ep)
    except Exception as e:  # noqa: BLE001
        fail("запрос не прошёл: %s" % e, endpoint=ep)

    items = out.get("images") or []
    if not items or not items[0].get("url"):
        # ВАЖНО: в raw НЕ отдаём CDN-ссылки fal — модель их вставит в ответ, а Telegram
        # такие не грузит (пользователь увидит пустой фон). Вырезаем любые URL.
        raw = re.sub(r"https?://\S+", "<url скрыт>", str(out))[:300]
        fail("в ответе fal нет картинок", raw=raw, endpoint=ep)

    home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    dstdir = os.path.join(home, "cache", "images")
    os.makedirs(dstdir, exist_ok=True)
    paths = []
    for n, it in enumerate(items):
        url = it["url"]
        ext = ".png" if ".png" in url.split("?")[0].lower() else ".jpg"
        dst = os.path.join(dstdir, "qwen_%s_%d%s%s" % (
            a.task, int(time.time()), "" if n == 0 else "_%d" % n, ext))
        urllib.request.urlretrieve(url, dst)
        paths.append(dst)

    res = {
        "image": paths[0],
        "telegram": "\n".join("MEDIA:" + p for p in paths),   # именно \n: через пробел гейтвей склеит пути в один и не отправит ничего
        "note": "вставь строку из поля telegram в ответ КАК ЕСТЬ; ссылки fal.media Telegram не грузит",
        "endpoint": ep,
        "inputs": len(a.image),
        "prompt_used": prompt,
        "prompt_source": src,
        "build_s": build_s,
        "elapsed_s": round(time.time() - t0, 1),
    }
    if len(paths) > 1:
        res["images"] = paths
    print(json.dumps(res, ensure_ascii=False))


if __name__ == "__main__":
    main()
