---
name: document-generation
description: Генерация красиво оформленных документов (DOCX/PDF) из markdown-аналитики с загрузкой на Google Диск. Для Андрея Анатольевича.
---

# document-generation — генерация отчётов и документов

Когда нужно превратить исследование/анализ в профессионально оформленный документ (DOCX + PDF)
и загрузить на Google Диск с открытым доступом.

## Триггеры
- «сделай документ/отчёт в DOCX/PDF»
- «сохрани анализ в файл на Google Диске»
- «красиво оформи»
- Любая задача вида «исследуй X и положи результат в файл»

## Основной пайплайн

### Шаг 1 — Собрать исходный контент

НИКОГДА не используй `read_file` для получения текста, который пойдёт в документ.
`read_file` возвращает строки с префиксами номеров (`    1|контент`), и они попадают в
итоговый файл.

**Правильно:**
```bash
cat /path/to/file.md
```
Или в execute_code: `terminal("cat /path/to/file.md")`.

### Шаг 2 — Создать стилизованный HTML

HTML даёт полный контроль над оформлением. Ключевые правила стиля:
- Шрифт: системный (Segoe UI / Arial), 13px для тела
- Заголовки: синяя полоса снизу (`border-bottom: 2px solid #2563eb`)
- Таблицы: синий заголовок (`#2563eb`), белый текст, зебра (`tr:nth-child(even)`)
- Блоки-выводы: светло-синий фон + левая синяя полоса
- Обложка: по центру, название + подзаголовок + дата
- Содержание в начале
- Секции разделены `<div class="section-divider">`

### Шаг 3 — Конвертировать в DOCX

```bash
pandoc input.html -o output.docx --from html --to docx
```

### Шаг 4 — Конвертировать в PDF

```bash
libreoffice --headless --convert-to pdf output.docx --outdir /path/
```

### Шаг 5 — Проверить количество страниц

```bash
pdfinfo output.pdf | grep Pages
```

### Шаг 6 — Загрузить на Google Диск

```bash
GAPI="python3 /root/.hermes/skills/productivity/google-workspace/scripts/google_api.py"
$GAPI drive upload /path/to/file.docx --name "Имя_файла.docx"
$GAPI drive upload /path/to/file.pdf --name "Имя_файла.pdf"
```

### Шаг 7 — Открыть доступ (ВСЕГДА)

```bash
$GAPI drive share FILE_ID --type anyone --role reader
```

## Питфолы

- **read_file даёт нумерацию строк** — `read_file` возвращает `    1|текст`. Для документов — только `terminal("cat")`.
- **pandoc из HTML надёжнее**, чем из markdown — markdown-таблицы и bold (`**`) могут сломаться при конвертации. HTML даёт полный контроль.
- **PDF через libreoffice** — pandoc → docx → libreoffice → pdf. Прямой pandoc → pdf даёт худший результат.
- **Всегда открывай доступ** — `--type anyone --role reader` при загрузке на Google Диск. Андрей Анатольевич ждёт, что файл открывается по ссылке без запроса доступа.
- **Проверяй страницы** — `pdfinfo` после генерации. Если больше ожидаемого — сокращай HTML.

## Пример: executive summary из нескольких .md

См. `references/example-pipeline.md`.
