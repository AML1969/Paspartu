# Calendar event updates via direct Python API

The `google_api.py` GAPI script supports `create`, `list`, `delete` but NOT `update`. For modifications like adding reminders, use direct Google API.

## Prerequisites

Token at `/root/.hermes/google_token.json`. Key field names (not standard Google format): `token` (not `access_token`), `refresh_token`, `token_uri`, `client_id`, `client_secret`.

## Adding a popup reminder

```python
import json
with open('/root/.hermes/google_token.json') as f:
    token_data = json.load(f)

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

creds = Credentials(
    token=token_data['token'],
    refresh_token=token_data['refresh_token'],
    token_uri=token_data['token_uri'],
    client_id=token_data['client_id'],
    client_secret=token_data['client_secret']
)
svc = build('calendar', 'v3', credentials=creds)

event = svc.events().get(calendarId='primary', eventId='EVENT_ID').execute()
event['reminders'] = {
    'useDefault': False,
    'overrides': [{'method': 'popup', 'minutes': 30}]
}
svc.events().update(calendarId='primary', eventId='EVENT_ID', body=event).execute()
```

## Renaming a Drive file

```python
svc = build('drive', 'v3', credentials=creds)
svc.files().update(fileId='FILE_ID', body={'name': 'new_name.jpg'}).execute()
```

## Pitfalls

- Token uses `token` key, NOT `access_token` — using `access_token` throws KeyError.
- Always use `/usr/bin/python3` (system Python with googleapiclient), not the Hermes venv python.
