# Добавление напоминаний к событиям Google Calendar

Штатный `$GAPI calendar create` не поддерживает флаг `--reminders`. Для добавления напоминаний — прямой вызов API через Python.

## Шаблон

```python
import json
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

# Читаем токен (формат Hermes: ключ 'token', не 'access_token')
with open('/root/.hermes/google_token.json') as f:
    td = json.load(f)

creds = Credentials(
    token=td['token'],
    refresh_token=td['refresh_token'],
    token_uri=td['token_uri'],
    client_id=td['client_id'],
    client_secret=td['client_secret']
)

service = build('calendar', 'v3', credentials=creds)

# Получить событие
event = service.events().get(calendarId='primary', eventId='EVENT_ID').execute()

# Установить напоминания
event['reminders'] = {
    'useDefault': False,
    'overrides': [
        {'method': 'popup', 'minutes': 30}  # за 30 мин
    ]
}

# Сохранить
service.events().update(calendarId='primary', eventId=event['id'], body=event).execute()
```

## Важно

- Токен Hermes использует ключ `token`, а не `access_token`.
- `client_id` и `client_secret` уже есть в `google_token.json`, не нужно читать отдельный `google_client_secret.json`.
