# Document Generation Pitfalls & Rules

## CRITICAL: read_file injects line numbers

`read_file()` returns content with line numbers: `    1|actual content`. When this content is passed to document generators (HTML→pandoc→docx→PDF), the line numbers end up in the final document as visible text.

**Rule:** When reading markdown content for document generation, use `terminal("cat /path/to/file")` instead of `read_file()`. Terminal output has no line numbers.

```python
# WRONG — line numbers leak into document
from hermes_tools import read_file
content = read_file("file.md")  # Returns "    1|# Title\n    2|text..."

# CORRECT — clean content
from hermes_tools import terminal
content = terminal("cat file.md")  # Returns "# Title\ntext..."
```

Also: if using `execute_code`, the `read_file` import from `hermes_tools` has the same line-number behavior. Always prefer `terminal("cat ...")` inside execute_code for document content.

## Always verify clean HTML

After building HTML from markdown, check for leftover `**` markers:

```python
import re
stars = re.findall(r'\*\*[^*]+\*\*', html)
# Replace any remaining:
html = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', html)
```

The per-line replacement in markdown→HTML converters often misses `**` inside table cells, list items, or multi-line contexts. A global regex post-processing step catches these.

## Conversion pipeline

```
Markdown → HTML (styled with CSS) → pandoc → DOCX → libreoffice → PDF
```

- `pandoc input.html -o output.docx --from html --to docx`
- `libreoffice --headless --convert-to pdf output.docx --outdir .`

Verify page count:
```bash
pdfinfo output.pdf | grep Pages
```

## Always share with public access

After uploading to Drive, immediately share:
```bash
$GAPI drive share FILE_ID --type anyone --role reader
```

The `drive upload` command does NOT grant public access by default.

## Page count targets

- Executive summary: 4–6 pages
- Full analysis: no explicit limit, but 30–40 pages typical for comprehensive reports
- Always verify with `pdfinfo` and report page count to user
