---
name: purchases-list
description: >
  Список покупок Андрея — отдельная система без календаря. Публикуется
  на paspartu.online/purchases.html. Триггеры: «купить», «добавь в покупки»,
  «отметь купленным», «что в покупках», «покажи покупки».
version: 1.0.0
---

# Список покупок

Отдельная от task-tracker система — без синхронизации с Google Calendar.

## Файлы
- Данные: `/root/hermes-workspace/purchases.json`
- Страница: `/var/www/paspartu.online/purchases.html` → [paspartu.online/purchases.html](https://paspartu.online/purchases.html)
- Скрипт: `/root/.hermes/scripts/purchases.py`

## Команды
```bash
PY=/root/.hermes/scripts/purchases.py

# Добавить покупку
python3 $PY add "Название товара"

# Отметить купленным (N — номер из list)
python3 $PY done N

# Вернуть в список (если отметил ошибочно)
python3 $PY undo N

# Добавить ссылку на товар
python3 $PY link N "https://..."

# Показать список (нумерация с 0)
python3 $PY list

# Перегенерировать HTML (после ручных правок JSON)
python3 $PY regen
```

## Когда пользователь говорит «купить X»
Просто выполни `python3 $PY add "X"` — скрипт сам обновит HTML.
Ответь коротко: «Добавил: X → paspartu.online/purchases.html».

## Когда пользователь говорит «купил X» / «отметь X»
Выполни `python3 $PY list` чтобы найти номер, затем `python3 $PY done N`.
Подтверди: «Отметил купленным: X».

## Когда просит «покажи покупки»
Просто дай ссылку: https://paspartu.online/purchases.html
