---
name: paspartu-online
description: Публикация контента на статический сайт paspartu.online через запись файлов в /var/www/paspartu.online.
---

# Публикация на paspartu.online

Сайт https://paspartu.online обслуживается Caddy как статический file server из каталога `/var/www/paspartu.online`. Чтобы опубликовать страницу — достаточно записать HTML-файл в этот каталог.

## URL-маппинг

- `/var/www/paspartu.online/index.html` → `paspartu.online`
- `/var/www/paspartu.online/foo.html` → `paspartu.online/foo.html`
- `/var/www/paspartu.online/shopping/index.html` → `paspartu.online/shopping/`
- Подкаталоги маппятся в URL-пути.

## Рабочий процесс

1. Создать файл через `write_file` в `/var/www/paspartu.online/<путь>`.
2. **Сразу после записи — поправить права.** `write_file` создаёт файлы с `600` (только root), а Caddy работает от другого пользователя и не может их прочитать. Результат: 404 при открытии в браузере.

```bash
chmod 644 /var/www/paspartu.online/<путь-к-файлу>
# для новых каталогов — ещё и на сам каталог:
chmod 755 /var/www/paspartu.online/<новый-каталог>/
```

3. Проверить доступность: `curl -sk https://paspartu.online/<путь> | head -5`

## Caddy

Конфиг: `/etc/caddy/Caddyfile`. Текущая конфигурация:

```
paspartu.online, www.paspartu.online {
    root * /var/www/paspartu.online
    file_server
    encode gzip
}
```

После изменений в конфиге: `systemctl reload caddy`.

## Интерактивные страницы

Для страниц с чек-листами и localStorage (списки покупок, задачи) используй паттерн:
- Карточки с tap-переключением состояния
- `localStorage` для сохранения между визитами
- Полоса прогресса
- Мобильный-first дизайн (max-width не нужен, просто резиновые карточки)

Подробный разбор паттерна: `references/shopping-checklist-pattern.md`.

## Pitfalls

- **Забыл chmod → 404.** Самая частая ошибка. После `write_file` в `/var/www/paspartu.online` файл недоступен для Caddy, пока не сделать `chmod 644`.
- **Новые каталоги.** `write_file` создаёт каталоги автоматически, но они тоже с `600`. Нужен `chmod 755` на каталог.
