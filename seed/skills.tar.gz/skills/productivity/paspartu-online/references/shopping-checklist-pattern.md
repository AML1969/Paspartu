# Паттерн: интерактивный список покупок

Одностраничный HTML с чек-листом покупок. Пользователь тапает по пункту — он вычёркивается. Состояние живёт в localStorage.

## Ключевые элементы

- **Карточки** с `border-radius: 14px`, `box-shadow`, светлый фон
- **Круглые чекбоксы** — SVG-галочка внутри круга, анимируется при checked
- **localStorage** — ключи `shop_0`..`shop_N`, значения `'1'` / `'0'`
- **Прогресс-бар** — flex-полоса с заполнением в процентах, текст `N/M`
- **Конфетти** — когда всё отмечено: 60 цветных частиц с CSS-анимацией `drop`
- **Кнопка сброса** — `resetAll()` удаляет все ключи из localStorage и перерендеривает
- **Мобильный-first** — `min-height: 100dvh`, `-webkit-tap-highlight-color: transparent`, резиновые карточки без media-query

## Структура JS

```js
const items = ['Пункт 1', 'Пункт 2', ...];

function render() {
  // очистить list.innerHTML
  // для каждого item: прочитать localStorage, создать div.item, добавить click→toggle(i)
  // обновить прогресс
}

function toggle(i) {
  // инвертировать localStorage, перерендерить
  // если отметили (не сняли) — проверить checkAllDone()
}

function updateProgress() { /* ширина progressFill, текст N/M или ✅ всё! */ }
function checkAllDone() { if all done → confetti() }
function resetAll() { очистить localStorage, render() }

function confetti() {
  // создать div.confetti, 60 div'ов с рандомными цветами/размерами
  // анимация drop через style.textContent (не в <style> чтобы рандомизировать translateX)
  // setTimeout удалить через 3с
}
```

## CSS-хитрости

- Анимация `drop` генерируется динамически (random translateX/rotate) — вставляется через `document.createElement('style')`
- Зачёркивание: `.item.checked .label { text-decoration: line-through; text-decoration-color: var(--green); }`
- Затемнение отмеченного: `.item.checked { opacity: 0.5; }`
- Цветовая схема: тёплый минимализм — `--bg: #faf7f2`, `--accent: #e8813b`, `--green: #5b9e6f`
