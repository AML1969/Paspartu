#!/usr/bin/env python3
"""Self-contained Google Calendar sync for the task-tracker skill.

Independent of the google-workspace skill: needs only the OAuth token file
<HERMES_HOME>/google_token.json (which itself carries client_id/secret/refresh_token).
Talks to Calendar API v3 over raw HTTPS.

Calendar model = POINT EVENTS (not spanning bars). A task surfaces as up to two
separate single-day all-day events:
  • START marker (🚀) on the start date — only when start is in the future;
  • DUE   marker (🏁) on the due date.
The creation date never goes on the calendar. See tasks.py:sync_calendar for which
events a given task gets.

Env:
  HERMES_HOME        default /root/.hermes
  TASKS_CALENDAR     default 'primary'
"""
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

API = "https://www.googleapis.com/calendar/v3"


def hermes_home() -> Path:
    return Path(os.environ.get("HERMES_HOME", "/root/.hermes"))


def token_path() -> Path:
    return hermes_home() / "google_token.json"


def default_calendar() -> str:
    return os.environ.get("TASKS_CALENDAR", "primary")


# ---------------------------------------------------------------- token

def _refresh(td: dict) -> dict:
    params = urllib.parse.urlencode({
        "client_id": td["client_id"],
        "client_secret": td["client_secret"],
        "refresh_token": td["refresh_token"],
        "grant_type": "refresh_token",
    }).encode()
    req = urllib.request.Request(td.get("token_uri", "https://oauth2.googleapis.com/token"), data=params)
    with urllib.request.urlopen(req, timeout=20) as resp:
        result = json.loads(resp.read())
    td["token"] = result["access_token"]
    td["expiry"] = (datetime.now(timezone.utc) + timedelta(seconds=result.get("expires_in", 3600))).isoformat()
    if not td.get("type"):
        td["type"] = "authorized_user"
    token_path().write_text(json.dumps(td, indent=2))
    return td


def get_token() -> str:
    p = token_path()
    if not p.exists():
        raise RuntimeError(f"No Google token at {p}. Run Google Workspace setup first.")
    td = json.loads(p.read_text())
    exp = td.get("expiry", "")
    needs = True
    if exp:
        try:
            needs = datetime.now(timezone.utc) >= datetime.fromisoformat(exp.replace("Z", "+00:00"))
        except ValueError:
            needs = True
    if needs or not td.get("token"):
        td = _refresh(td)
    return td["token"]


# ---------------------------------------------------------------- REST

def _api(method: str, path: str, body: dict | None = None, params: dict | None = None) -> dict:
    token = get_token()
    url = API + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            raw = resp.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Calendar API {method} {path} failed (HTTP {e.code}): {detail}")


# ---------------------------------------------------------------- helpers

def _d(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


def build_summary(title: str, level1: str, counterparty: str, status: str,
                  marker: str, paired: bool) -> str:
    """Event title.

    marker = 'start' | 'due'.  paired=True when BOTH a start and a due marker
    exist for this task (then we add « — старт»/« — срок» to tell them apart);
    when the task has only one event, paired=False and the emoji alone carries
    the meaning.
    """
    tag = level1 or ""
    if counterparty:
        tag = f"{tag}·{counterparty}" if tag else counterparty
    head = f"[{tag}] " if tag else ""
    emoji = "🚀" if marker == "start" else "🏁"
    suffix = ""
    if paired:
        suffix = " — старт" if marker == "start" else " — срок"
    s = f"{emoji} {head}{title}{suffix}"
    if status == "done":
        s = "✓ " + s
    return s


def _all_day_body(summary: str, on_date: str, description: str = "") -> dict:
    start = _d(on_date)
    end_excl = start + timedelta(days=1)              # single all-day, Google end is exclusive
    return {
        "summary": summary,
        "description": description or "",
        "start": {"date": start.isoformat()},
        "end": {"date": end_excl.isoformat()},
        "transparency": "transparent",               # don't block free/busy
    }


# ---------------------------------------------------------------- public ops

def create_event(summary: str, on_date: str, description: str = "", calendar: str | None = None) -> str:
    cal = calendar or default_calendar()
    body = _all_day_body(summary, on_date, description)
    res = _api("POST", f"/calendars/{urllib.parse.quote(cal)}/events", body=body)
    return res.get("id", "")


def update_event(event_id: str, summary: str, on_date: str, description: str = "", calendar: str | None = None) -> str:
    """PATCH a point event in place; if it's gone, recreate it and return the new id."""
    cal = calendar or default_calendar()
    body = _all_day_body(summary, on_date, description)
    try:
        res = _api("PATCH", f"/calendars/{urllib.parse.quote(cal)}/events/{urllib.parse.quote(event_id)}", body=body)
        return res.get("id", event_id)
    except RuntimeError as e:
        if "HTTP 404" in str(e) or "HTTP 410" in str(e):
            return create_event(summary, on_date, description, cal)
        raise


def upsert_event(event_id: str, summary: str, on_date: str, description: str = "", calendar: str | None = None) -> str:
    """Create if no id yet, otherwise PATCH (recreate on 404). Returns the live id."""
    if event_id and event_id.strip():
        return update_event(event_id.strip(), summary, on_date, description, calendar)
    return create_event(summary, on_date, description, calendar)


def delete_event(event_id: str, calendar: str | None = None) -> None:
    if not event_id or not event_id.strip():
        return
    cal = calendar or default_calendar()
    try:
        _api("DELETE", f"/calendars/{urllib.parse.quote(cal)}/events/{urllib.parse.quote(event_id.strip())}")
    except RuntimeError as e:
        if "HTTP 404" in str(e) or "HTTP 410" in str(e):
            return
        raise


if __name__ == "__main__":
    # tiny smoke test: gcal.py token   -> prints OK if token usable
    if len(sys.argv) > 1 and sys.argv[1] == "token":
        try:
            t = get_token()
            print("TOKEN OK" if t else "TOKEN EMPTY")
        except Exception as e:  # noqa
            print(f"TOKEN FAIL: {e}")
            sys.exit(1)
