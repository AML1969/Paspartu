#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""task-tracker — обособленный блок задач для Hermes.

Каждая задача — отдельный markdown-файл (YAML-подобная шапка) в плоской папке
TASKS_DIR. В Google Calendar задача отражается ТОЧЕЧНЫМИ событиями (не «брусом»):
отдельная отметка 🚀 «старт» на дату начала (только если начало в будущем) и/или
отметка 🏁 «срок» на дату завершения. Дата создания — внутренняя, в календарь не идёт.

CLI:
  add      создать задачу (+ события в календаре)
  list     список с фильтрами (--level1/--counterparty/--status/--overdue/--today)
  search   поиск по всем полям (контрагент, теги, ключевые слова, название, примечания)
  show     показать одну задачу
  update   изменить поля (+ обновить события)
  close    закрыть (status=done, ✓ на событиях, события остаются)
  reopen   снова открыть
  delete   удалить задачу (и её события)
  digest   текст утреннего дайджеста (старт сегодня / срок сегодня / просрочено / скоро срок)
  reindex  перестроить INDEX.md
  resync   пересоздать/обновить события календаря для всех задач

Три даты: created (авто, ВНУТРЕННЯЯ — не в календарь), start (начало; по умолчанию = created;
можно задать будущую), due (срок/дедлайн, опц.). lead_days — за сколько дней до срока
предупреждать заранее (по умолчанию 1).
"""
import argparse
import html
import os
import re
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gcal  # noqa: E402

LEVELS = ["Личное", "Рабочее", "Семья"]          # расширяемо; не валидируем жёстко
LIST_FIELDS = {"level2", "keywords"}
FIELD_ORDER = ["id", "title", "level1", "level2", "counterparty",
               "created", "start", "due", "status", "keywords", "lead_days",
               "gcal_start_event_id", "gcal_due_event_id", "gcal_calendar"]
DEFAULT_LEAD = 1
MONTHS_RU = ["", "янв", "фев", "мар", "апр", "мая", "июн",
             "июл", "авг", "сен", "окт", "ноя", "дек"]
WDAYS_RU = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]


def tasks_dir() -> Path:
    d = Path(os.environ.get("TASKS_DIR", "/root/hermes-workspace/tasks"))
    d.mkdir(parents=True, exist_ok=True)
    return d


def today() -> date:
    return date.today()


def today_iso() -> str:
    return today().isoformat()


# ----------------------------------------------------------------- date utils

def _pdate(s: str) -> date | None:
    s = (s or "").strip()
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        return None


def fmt_human(s: str) -> str:
    """'2026-06-12' -> '12 июн, пт'. Пусто -> ''."""
    d = _pdate(s)
    if not d:
        return ""
    return f"{d.day} {MONTHS_RU[d.month]}, {WDAYS_RU[d.weekday()]}"


def _esc(s: str) -> str:
    return html.escape(str(s or ""))


# ----------------------------------------------------------------- telegram push

def _load_env_file(p: Path):
    if not p.exists():
        return
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def tg_send(text: str) -> None:
    """Отправить готовое HTML-сообщение прямо в домашний чат бота (минуя пересказ модели)."""
    import urllib.parse
    import urllib.request
    _load_env_file(Path(os.environ.get("HERMES_ENV", "/root/.hermes/.env")))
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat = os.environ.get("TELEGRAM_HOME_CHANNEL", "")
    thread = os.environ.get("TELEGRAM_HOME_CHANNEL_THREAD_ID", "")
    if not token or not chat:
        print("ERROR: TELEGRAM_BOT_TOKEN / TELEGRAM_HOME_CHANNEL not set", file=sys.stderr)
        return
    payload = {"chat_id": chat, "text": text, "parse_mode": "HTML",
               "disable_web_page_preview": True}
    if thread:
        payload["message_thread_id"] = thread
    data = urllib.parse.urlencode(payload).encode()
    req = urllib.request.Request(f"https://api.telegram.org/bot{token}/sendMessage", data=data)
    with urllib.request.urlopen(req, timeout=20) as resp:
        import json as _json
        _json.loads(resp.read())


# ----------------------------------------------------------------- parse/dump

def _split_list(v: str) -> list[str]:
    return [x.strip() for x in v.split(",") if x.strip()]


def parse_file(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    fm, body = {}, ""
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            for line in parts[1].strip().splitlines():
                if ":" not in line:
                    continue
                k, _, v = line.partition(":")
                k, v = k.strip(), v.strip()
                fm[k] = _split_list(v) if k in LIST_FIELDS else v
            body = parts[2].lstrip("\n")
    fm.setdefault("level2", [])
    fm.setdefault("keywords", [])
    # дата начала по умолчанию = дата создания (для старых файлов без start)
    if not fm.get("start"):
        fm["start"] = fm.get("created", "")
    fm["notes"] = body.strip()
    fm["_path"] = str(path)
    return fm


def dump_file(task: dict) -> str:
    lines = ["---"]
    for k in FIELD_ORDER:
        v = task.get(k, "")
        if k in LIST_FIELDS:
            v = ", ".join(v if isinstance(v, list) else _split_list(str(v)))
        lines.append(f"{k}: {v}")
    lines.append("---")
    lines.append("")
    lines.append((task.get("notes") or "").strip())
    lines.append("")
    return "\n".join(lines)


def save(task: dict) -> Path:
    path = Path(task.get("_path") or tasks_dir() / f"{task['id']}.md")
    path.write_text(dump_file(task), encoding="utf-8")
    task["_path"] = str(path)
    return path


def load_all() -> list[dict]:
    out = []
    for p in sorted(tasks_dir().glob("T-*.md")):
        try:
            out.append(parse_file(p))
        except Exception as e:  # noqa
            print(f"WARN: cannot parse {p}: {e}", file=sys.stderr)
    return out


def get_task(tid: str) -> dict | None:
    tid = tid.strip().upper()
    if not tid.startswith("T-") and tid.isdigit():
        tid = f"T-{int(tid):04d}"
    p = tasks_dir() / f"{tid}.md"
    return parse_file(p) if p.exists() else None


def next_id() -> str:
    mx = 0
    for p in tasks_dir().glob("T-*.md"):
        m = re.match(r"T-(\d+)", p.stem)
        if m:
            mx = max(mx, int(m.group(1)))
    return f"T-{mx + 1:04d}"


def _lead(t: dict) -> int:
    raw = str(t.get("lead_days", "")).strip()
    if raw.isdigit():
        return max(0, int(raw))
    return DEFAULT_LEAD


# ----------------------------------------------------------------- calendar glue

def _which_events(task: dict):
    """Решает, какие точечные события нужны задаче.

    Возвращает (show_start, show_due):
      show_start — отметка 🚀 «старт» на дату начала;
      show_due   — отметка 🏁 «срок» на дату завершения (если срок задан).
    Правило (каждая задача видна в календаре хотя бы одной отметкой):
      • срок есть → всегда 🏁 на дату срока;
      • старт показываем, если он НЕ совпадает с датой срока И при этом либо у задачи
        нет срока (иначе её вообще не было бы в календаре — кладём на дату начала),
        либо старт в будущем (осмысленная отдельная отметка «старт»);
      • старт == срок → одна отметка (срок).
    Дата создания сама по себе в календарь не идёт; но дефолтный старт = дате создания,
    поэтому бессрочная задача появляется на дне создания.
    """
    start, due, td = task.get("start", ""), task.get("due", ""), today_iso()
    show_due = bool(due)
    show_start = bool(start) and start != due and ((not due) or start > td)
    return show_start, show_due


def sync_calendar(task: dict) -> None:
    cal = task.get("gcal_calendar") or gcal.default_calendar()

    # миграция со старой однособытийной модели: удаляем «брус», если остался
    legacy = (task.pop("gcal_event_id", "") or "").strip()
    if legacy:
        try:
            gcal.delete_event(legacy, cal)
        except Exception as e:  # noqa
            print(f"WARN: legacy event cleanup failed for {task.get('id')}: {e}", file=sys.stderr)

    show_start, show_due = _which_events(task)
    paired = show_start and show_due

    desc_bits = [f"{task['id']}"]
    if task.get("level2"):
        desc_bits.append("теги: " + ", ".join(task["level2"]))
    if task.get("notes"):
        desc_bits.append(task["notes"])
    description = "\n".join(desc_bits)

    # START marker
    try:
        if show_start:
            summ = gcal.build_summary(task["title"], task.get("level1", ""),
                                      task.get("counterparty", ""), task.get("status", "open"),
                                      "start", paired)
            task["gcal_start_event_id"] = gcal.upsert_event(
                task.get("gcal_start_event_id", ""), summ, task["start"], description, cal)
        elif (task.get("gcal_start_event_id", "") or "").strip():
            gcal.delete_event(task["gcal_start_event_id"], cal)
            task["gcal_start_event_id"] = ""
    except Exception as e:  # noqa — календарь best-effort, задача всё равно сохраняется
        print(f"WARN: calendar start-sync failed for {task['id']}: {e}", file=sys.stderr)

    # DUE marker
    try:
        if show_due:
            summ = gcal.build_summary(task["title"], task.get("level1", ""),
                                      task.get("counterparty", ""), task.get("status", "open"),
                                      "due", paired)
            task["gcal_due_event_id"] = gcal.upsert_event(
                task.get("gcal_due_event_id", ""), summ, task["due"], description, cal)
        elif (task.get("gcal_due_event_id", "") or "").strip():
            gcal.delete_event(task["gcal_due_event_id"], cal)
            task["gcal_due_event_id"] = ""
    except Exception as e:  # noqa
        print(f"WARN: calendar due-sync failed for {task['id']}: {e}", file=sys.stderr)

    task["gcal_calendar"] = cal


def drop_calendar(task: dict) -> None:
    """Удалить ВСЕ события задачи (для удаления задачи)."""
    cal = task.get("gcal_calendar") or gcal.default_calendar()
    for k in ("gcal_start_event_id", "gcal_due_event_id", "gcal_event_id"):
        eid = (task.get(k, "") or "").strip()
        if eid:
            try:
                gcal.delete_event(eid, cal)
            except Exception as e:  # noqa
                print(f"WARN: delete event {eid} failed: {e}", file=sys.stderr)
        task[k] = ""


# ----------------------------------------------------------------- index

def reindex() -> Path:
    rows = sorted(load_all(), key=lambda t: t["id"])
    lines = ["# Индекс задач", "", f"_обновлено {datetime.now():%Y-%m-%d %H:%M}_", "",
             "| ID | Кат. | Контрагент | Задача | Начало | Срок | Статус |",
             "|----|------|-----------|--------|--------|------|--------|"]
    for t in rows:
        lines.append("| {id} | {l1} | {cp} | {title} | {st} | {due} | {status} |".format(
            id=t["id"], l1=t.get("level1", ""), cp=t.get("counterparty", "") or "—",
            title=t.get("title", "").replace("|", "/"),
            st=t.get("start", "") or "—", due=t.get("due", "") or "∞",
            status=t.get("status", "")))
    p = tasks_dir() / "INDEX.md"
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return p


# ----------------------------------------------------------------- search/filter

def _blob(t: dict) -> str:
    parts = [t.get("id", ""), t.get("title", ""), t.get("level1", ""),
             t.get("counterparty", ""), t.get("notes", "")]
    parts += t.get("level2", []) + t.get("keywords", [])
    return " ".join(parts).lower()


def search(query: str) -> list[dict]:
    terms = [w for w in query.lower().split() if w]
    res = []
    for t in load_all():
        blob = _blob(t)
        if all(term in blob for term in terms):
            res.append(t)
    return res


def _is_overdue(t: dict) -> bool:
    return bool(t.get("due")) and t["status"] != "done" and t["due"] < today_iso()


def _due_today(t: dict) -> bool:
    return t.get("due") == today_iso() and t["status"] != "done"


def _starts_today(t: dict) -> bool:
    # объявляем старт, только если начало действительно задано на сегодня и
    # отличается от даты создания (т.е. это явный будущий старт, который наступил)
    return (t.get("start") == today_iso() and t.get("start") != t.get("created")
            and t["status"] != "done")


def _due_soon(t: dict) -> bool:
    if t["status"] == "done" or not t.get("due"):
        return False
    d = _pdate(t["due"])
    if not d:
        return False
    delta = (d - today()).days
    return delta == _lead(t) and delta > 0


def _tag(t: dict) -> str:
    cp = f"·{t['counterparty']}" if t.get("counterparty") else ""
    lvl = t.get("level1", "")
    return f"[{lvl}{cp}]" if (lvl or cp) else ""


def _dates_html(t: dict) -> str:
    """Подстрока с датами/статусом для строки списка (HTML)."""
    bits = []
    start, due, td = t.get("start", ""), t.get("due", ""), today_iso()
    if start and start > td:
        bits.append(f"🚀 старт {fmt_human(start)}")
    if due:
        if _is_overdue(t):
            n = (today() - _pdate(due)).days
            bits.append(f"⚠️ просрочено {n} {_days_word(n)} (было {fmt_human(due)})")
        elif _due_today(t):
            bits.append("🔥 срок сегодня")
        else:
            bits.append(f"🏁 до {fmt_human(due)}")
    else:
        bits.append("♾️ без срока")
    return " · ".join(bits)


def _item_html(t: dict, strike: bool = False) -> str:
    tag = _esc(_tag(t))
    title = _esc(t.get("title", ""))
    head = f"<code>{_esc(t['id'])}</code> {tag} {title}".replace("  ", " ").strip()
    if strike:
        head = f"<s>{head}</s>"
    return f"▪️ {head}\n      {_dates_html(t)}"


def render_list(rows: list[dict], emoji: str, title: str) -> str:
    """Сгруппированный по статусу список (HTML, шлётся напрямую в Telegram)."""
    if not rows:
        return f"{emoji} <b>{_esc(title)}</b>\n\n<i>ничего не найдено</i>"
    groups = {"overdue": [], "open": [], "inprogress": [], "done": []}
    for t in rows:
        st = t.get("status")
        if st == "done":
            groups["done"].append(t)
        elif _is_overdue(t):
            groups["overdue"].append(t)
        elif st == "in_progress":
            groups["inprogress"].append(t)
        else:
            groups["open"].append(t)
    out = [f"{emoji} <b>{_esc(title)} — {len(rows)}</b>", ""]
    for key, hdr in (("overdue", "⚠️ <b>Просрочено</b>"), ("open", "🟢 <b>Открытые</b>"),
                     ("inprogress", "🔵 <b>В работе</b>"), ("done", "✅ <b>Завершено</b>")):
        g = groups[key]
        if not g:
            continue
        out.append(hdr)
        out += [_item_html(t, strike=(key == "done")) for t in g]
        out.append("")
    return "\n".join(out).strip()



# --- RU tracker rich-list patch ---
def _rich_flag_on() -> bool:
    _load_env_file(Path(os.environ.get("HERMES_ENV", "/root/.hermes/.env")))
    return os.environ.get("HERMES_RICH_MESSAGES", "").lower() in ("1", "true", "yes")


def tg_send_rich(markdown: str) -> bool:
    """sendRichMessage с markdown-таблицей. True = успех, False = нужен фоллбэк."""
    import json as _json
    import urllib.request
    _load_env_file(Path(os.environ.get("HERMES_ENV", "/root/.hermes/.env")))
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat = os.environ.get("TELEGRAM_HOME_CHANNEL", "")
    if not token or not chat:
        return False
    try:
        req = urllib.request.Request(
            "https://api.telegram.org/bot%s/sendRichMessage" % token,
            data=_json.dumps({"chat_id": int(chat),
                              "rich_message": {"markdown": markdown}}).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            return bool(_json.loads(resp.read()).get("ok"))
    except Exception:
        return False


def _md_cell(s: str) -> str:
    return (s or "").replace("|", "/").replace("\n", " ").strip()


def render_list_rich(rows: list[dict], emoji: str, title: str) -> str:
    """Список задач как markdown-таблицы по статус-группам (для sendRichMessage)."""
    if not rows:
        return "## %s %s\n\n_ничего не найдено_" % (emoji, title)
    groups = {"overdue": [], "open": [], "inprogress": [], "done": []}
    for t in rows:
        st = t.get("status")
        if st == "done":
            groups["done"].append(t)
        elif _is_overdue(t):
            groups["overdue"].append(t)
        elif st == "in_progress":
            groups["inprogress"].append(t)
        else:
            groups["open"].append(t)
    out = ["# %s %s — %d\n" % (emoji, title, len(rows))]
    for key, hdr in (("overdue", "⚠️ Просрочено"), ("open", "🟢 Открытые"),
                     ("inprogress", "🔵 В работе"), ("done", "✅ Завершено")):
        g = groups[key]
        if not g:
            continue
        out.append("## %s\n" % hdr)
        out.append("| № | Задача | Проект | Срок |")
        out.append("|---|---|---|---|")
        for t in g:
            proj = t.get("level1", "") or ""
            cp = t.get("counterparty") or ""
            if cp:
                proj = "%s · %s" % (proj, cp) if proj else cp
            due = t.get("due", "")
            start = t.get("start", "")
            bits = []
            if start and start > today_iso():
                bits.append("🚀 " + fmt_human(start))
            bits.append("🏁 " + fmt_human(due) if due else "♾️")
            title_cell = _md_cell(t.get("title", ""))
            if key == "done":
                title_cell = "~~%s~~" % title_cell
            out.append("| `%s` | %s | %s | %s |" % (
                t["id"], title_cell, _md_cell(proj), _md_cell(" · ".join(bits))))
        out.append("")
    return "\n".join(out).strip()


def _emit_list(a, rows, emoji: str, title: str) -> None:
    """--send: пробуем rich-таблицу, при неудаче — старый HTML-путь."""
    if getattr(a, "send", False) and getattr(a, "rich", False):
        try:
            if tg_send_rich(render_list_rich(rows, emoji, title)):
                print("📤 Отправлено в Telegram (rich).")
                return
        except Exception:
            pass
    _emit(a, render_list(rows, emoji, title))
# --- end RU tracker rich-list patch ---

def render_card(t: dict, kind: str = "show") -> str:
    """Карточка задачи (HTML). kind: created|closed|show."""
    if kind == "created":
        head = f"✅ <b>Создал</b> · <code>{_esc(t['id'])}</code>"
    elif kind == "closed":
        head = f"✅ <b>Закрыл</b> · <code>{_esc(t['id'])}</code>"
    else:
        head = f"📝 <b>Задача</b> · <code>{_esc(t['id'])}</code>"
    lines = [head, "", f"📌 <b>{_esc(t.get('title',''))}</b>",
             f"🗂 {_esc(t.get('level1','—'))} · 👤 {_esc(t.get('counterparty') or '—')}"]
    if t.get("level2"):
        lines.append(f"🏷 {_esc(', '.join(t['level2']))}")
    start, due = t.get("start", ""), t.get("due", "")
    if start and start > today_iso():
        lines.append(f"🚀 Начало — {fmt_human(start)}")
    if due:
        lines.append(f"🏁 Срок — {fmt_human(due)}")
        lines.append(f"🔔 Напомню за {_lead(t)} {_days_word(_lead(t))} до срока + в день срока")
    else:
        lines.append("♾️ Без срока")
    sid = (t.get("gcal_start_event_id", "") or "").strip()
    did = (t.get("gcal_due_event_id", "") or "").strip()
    cal = []
    if sid: cal.append(f"🚀 {fmt_human(start) or _esc(start)}")
    if did: cal.append(f"🏁 {fmt_human(due) or _esc(due)}")
    lines.append(f"🗓 Календарь: {' + '.join(cal) if cal else '—'}")
    if kind == "show" and t.get("notes"):
        lines += ["", f"📝 {_esc(t['notes'])}"]
    return "\n".join(lines)


def _emit(a, text: str) -> None:
    """--send → отправить готовый HTML прямо в Telegram; иначе печать в stdout."""
    if getattr(a, "send", False):
        try:
            tg_send(text)
            print("📤 Отправлено в Telegram.")
        except Exception as e:  # noqa
            print(f"SEND FAIL: {e}", file=sys.stderr)
            print(text)
    else:
        print(text)


# ----------------------------------------------------------------- digest

def _days_word(n: int) -> str:
    n = abs(n)
    if n % 10 == 1 and n % 100 != 11:
        return "день"
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return "дня"
    return "дней"


def _digest_line(t: dict, extra: str = "") -> str:
    cp = f"·{_esc(t['counterparty'])}" if t.get("counterparty") else ""
    lvl = _esc(t.get("level1", ""))
    tag = f"[{lvl}{cp}] " if (lvl or cp) else ""
    title = _esc(t.get("title", ""))
    suffix = f" — {extra}" if extra else ""
    return f"   • {tag}{title}{suffix} <code>{_esc(t['id'])}</code>"


def build_digest() -> str:
    """Утренний дайджест в HTML (для Telegram). Пусто, если объявлять нечего."""
    allt = load_all()
    starts = [t for t in allt if _starts_today(t)]
    due_today = [t for t in allt if _due_today(t)]
    overdue = sorted([t for t in allt if _is_overdue(t)], key=lambda x: x["due"])
    soon = sorted([t for t in allt if _due_soon(t)], key=lambda x: x["due"])
    if not (starts or due_today or overdue or soon):
        return ""  # тихо — объявлять нечего

    d = today()
    out = [f"☀️ <b>Доброе утро! Сводка · {d.day} {MONTHS_RU[d.month]}</b>", ""]

    if starts:
        out.append("🚀 <b>Сегодня стартуют</b>")
        out += [_digest_line(t) for t in starts]
        out.append("")
    if due_today:
        out.append("🔥 <b>Срок сегодня</b>")
        out += [_digest_line(t) for t in due_today]
        out.append("")
    if overdue:
        out.append("⚠️ <b>Просрочено</b>")
        for t in overdue:
            n = (today() - _pdate(t["due"])).days
            out.append(_digest_line(t, f"{n} {_days_word(n)}"))
        out.append("")
    if soon:
        out.append("⏰ <b>Скоро срок</b>")
        for t in soon:
            n = (_pdate(t["due"]) - today()).days
            extra = "завтра" if n == 1 else f"через {n} {_days_word(n)}"
            out.append(_digest_line(t, extra))
        out.append("")

    open_total = len([t for t in allt if t["status"] != "done"])
    out.append("──────────────")
    out.append(f"📊 Открытых всего — {open_total}")
    return "\n".join(out).strip()


# ----------------------------------------------------------------- commands

def cmd_add(a):
    created = today_iso()
    start = (a.start or "").strip() or created
    t = {
        "id": next_id(),
        "title": a.title.strip(),
        "level1": (a.level1 or "").strip(),
        "level2": _split_list(a.tags or ""),
        "counterparty": (a.counterparty or "").strip(),
        "created": created,
        "start": start,
        "due": (a.due or "").strip(),
        "status": (a.status or "open").strip(),
        "keywords": _split_list(a.keywords or ""),
        "lead_days": str(a.lead).strip() if a.lead is not None else "",
        "gcal_start_event_id": "",
        "gcal_due_event_id": "",
        "gcal_calendar": (a.calendar or gcal.default_calendar()),
        "notes": (a.notes or "").strip(),
    }
    if not a.no_calendar:
        sync_calendar(t)
    save(t)
    reindex()
    _emit(a, render_card(t, "created"))


def cmd_update(a):
    t = get_task(a.id)
    if not t:
        print(f"Не найдено: {a.id}"); sys.exit(2)
    if a.title is not None: t["title"] = a.title.strip()
    if a.level1 is not None: t["level1"] = a.level1.strip()
    if a.counterparty is not None: t["counterparty"] = a.counterparty.strip()
    if a.start is not None: t["start"] = a.start.strip() or t.get("created", "")
    if a.due is not None: t["due"] = a.due.strip()
    if a.status is not None: t["status"] = a.status.strip()
    if a.notes is not None: t["notes"] = a.notes.strip()
    if a.tags is not None: t["level2"] = _split_list(a.tags)
    if a.add_tag: t["level2"] = list(dict.fromkeys(t["level2"] + _split_list(a.add_tag)))
    if a.keywords is not None: t["keywords"] = _split_list(a.keywords)
    if a.lead is not None: t["lead_days"] = str(a.lead).strip()
    if not a.no_calendar:
        sync_calendar(t)
    save(t)
    reindex()
    _emit(a, render_card(t, "show"))


def cmd_close(a):
    t = get_task(a.id)
    if not t:
        print(f"Не найдено: {a.id}"); sys.exit(2)
    t["status"] = "done"
    if not a.no_calendar:
        sync_calendar(t)              # ставит ✓, события остаются
    save(t)
    reindex()
    _emit(a, render_card(t, "closed"))


def cmd_reopen(a):
    t = get_task(a.id)
    if not t:
        print(f"Не найдено: {a.id}"); sys.exit(2)
    t["status"] = "open"
    if not a.no_calendar:
        sync_calendar(t)
    save(t)
    reindex()
    _emit(a, render_card(t, "show"))


def cmd_delete(a):
    t = get_task(a.id)
    if not t:
        print(f"Не найдено: {a.id}"); sys.exit(2)
    if not a.no_calendar:
        drop_calendar(t)
    p = Path(t["_path"])
    if p.exists():
        p.unlink()
    reindex()
    _emit(a, f"🗑 <b>Удалил</b> · <code>{_esc(t['id'])}</code> {_esc(t.get('title',''))}")


def cmd_list(a):
    rows = load_all()
    if a.level1: rows = [t for t in rows if t.get("level1", "").lower() == a.level1.lower()]
    if a.counterparty: rows = [t for t in rows if a.counterparty.lower() in t.get("counterparty", "").lower()]
    if a.status: rows = [t for t in rows if t.get("status") == a.status]
    if a.overdue: rows = [t for t in rows if _is_overdue(t)]
    if a.today: rows = [t for t in rows if _due_today(t)]
    if a.no_due: rows = [t for t in rows if not t.get("due")]
    if a.upcoming: rows = [t for t in rows if t.get("due") and t["due"] > today_iso()]
    if not a.all and not a.status:
        rows = [t for t in rows if t.get("status") != "done"]
    rows.sort(key=lambda t: (t.get("due") or "9999", t["id"]))
    title = "Задачи"
    if a.overdue: title = "Просроченные"
    elif a.today: title = "Срок сегодня"
    elif a.no_due: title = "Бессрочные"
    elif a.upcoming: title = "Ближайшие сроки"
    elif a.level1: title = f"Раздел: {a.level1}"
    elif a.counterparty: title = f"Контрагент: {a.counterparty}"
    elif a.all: title = "Все задачи"
    _emit_list(a, rows, "📋", title)


def cmd_search(a):
    q = " ".join(a.query)
    rows = search(q)
    _emit_list(a, rows, "🔎", f"«{q}»")


def cmd_show(a):
    t = get_task(a.id)
    if not t:
        print(f"Не найдено: {a.id}"); sys.exit(2)
    _emit(a, render_card(t, "show"))


def cmd_digest(a):
    txt = build_digest()
    if txt:
        print(txt)
    elif not a.quiet_if_empty:
        print(f"☀️ На {today():%d.%m} объявлять нечего — сводка пустая (HTML; для бота используй list).")


def cmd_reindex(a):
    p = reindex()
    print(f"Индекс обновлён: {p}")


def cmd_resync(a):
    n = 0
    for t in load_all():
        sync_calendar(t); save(t); n += 1
    reindex()
    print(f"Пересинхронизировано задач: {n}")


def main():
    p = argparse.ArgumentParser(prog="tasks", description="Блок задач Hermes")
    sub = p.add_subparsers(dest="cmd", required=True)

    def add_cal_flag(x): x.add_argument("--no-calendar", action="store_true", help="не трогать Google Calendar")
    def add_send_flag(x): x.add_argument("--send", action="store_true", help="отправить готовый HTML прямо в Telegram")

    a = sub.add_parser("add"); a.add_argument("--title", required=True)
    a.add_argument("--level1"); a.add_argument("--counterparty")
    a.add_argument("--start"); a.add_argument("--due"); a.add_argument("--lead", type=int)
    a.add_argument("--tags"); a.add_argument("--keywords"); a.add_argument("--notes")
    a.add_argument("--status", default="open"); a.add_argument("--calendar")
    add_cal_flag(a); add_send_flag(a); a.set_defaults(func=cmd_add)

    u = sub.add_parser("update"); u.add_argument("id")
    for f in ("title", "level1", "counterparty", "start", "due", "status", "notes", "tags", "keywords", "add-tag"):
        u.add_argument(f"--{f}")
    u.add_argument("--lead", type=int)
    add_cal_flag(u); add_send_flag(u); u.set_defaults(func=cmd_update)

    for name, fn in (("close", cmd_close), ("reopen", cmd_reopen), ("delete", cmd_delete)):
        c = sub.add_parser(name); c.add_argument("id"); add_cal_flag(c); add_send_flag(c); c.set_defaults(func=fn)

    l = sub.add_parser("list"); l.add_argument("--rich", action="store_true")
    l.add_argument("--level1"); l.add_argument("--counterparty"); l.add_argument("--status")
    l.add_argument("--overdue", action="store_true"); l.add_argument("--today", action="store_true")
    l.add_argument("--no-due", action="store_true"); l.add_argument("--upcoming", action="store_true")
    l.add_argument("--all", action="store_true"); add_send_flag(l); l.set_defaults(func=cmd_list)

    s = sub.add_parser("search"); s.add_argument("--rich", action="store_true"); s.add_argument("query", nargs="+"); add_send_flag(s); s.set_defaults(func=cmd_search)
    sh = sub.add_parser("show"); sh.add_argument("id"); add_send_flag(sh); sh.set_defaults(func=cmd_show)
    d = sub.add_parser("digest"); d.add_argument("--quiet-if-empty", action="store_true"); d.set_defaults(func=cmd_digest)
    sub.add_parser("reindex").set_defaults(func=cmd_reindex)
    sub.add_parser("resync").set_defaults(func=cmd_resync)

    args = p.parse_args()  # argparse maps --add-tag -> args.add_tag
    args.func(args)


if __name__ == "__main__":
    main()
