# Установка / переустановка

Канонический исходник скилла лежит на сервере в `/root/hermes-task-tracker-src/`
(не стирается при `hermes update`). Установка — идемпотентным `install.sh`.

```bash
bash /root/hermes-task-tracker-src/install.sh
```

После `hermes update` (стирает код скиллов) — просто повтори команду выше: она заново
разложит скилл, восстановит cron и исключение в AGENTS.md. Данные задач (`tasks/*.md`)
не трогаются.

## Изолированный профиль (для второго пользователя)
Запусти install.sh с путями нужного профиля, например:

```bash
HERMES_HOME=/root/.hermes-friend \
WORKSPACE=/root/hermes-workspace-friend \
bash /root/hermes-task-tracker-src/install.sh
```

Требование: в этом профиле должен быть авторизован Google (есть
`$HERMES_HOME/google_token.json`) и в `$HERMES_HOME/.env` заданы `TELEGRAM_BOT_TOKEN`
и `TELEGRAM_HOME_CHANNEL`. Подробности — в pipeline-документе проекта.
