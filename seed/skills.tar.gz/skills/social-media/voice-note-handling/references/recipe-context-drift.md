# Recipe context drift patterns

Use these patterns when a user is correcting a recipe over multiple voice notes.

## What happened in the session
- The user first asked about a Ukrainian red borscht with mushrooms.
- The assistant drifted to meat and then to extra ingredients, which the user explicitly corrected.
- The user then fixed ingredient-by-ingredient constraints:
  - no celery
  - must be mushrooms, not meat
  - Thermomix instructions are required
  - no garlic
  - no vegetable broth; use boiled water + mushroom soaking liquid

## Durable lesson
Treat the current recipe as a stateful object:
- maintain dish identity across turns
- preserve the appliance/method once established
- only change the exact ingredient or step the user corrected
- after a correction, restate the active recipe before continuing

## Response pattern
1. Confirm the corrected constraint in one line.
2. Rebuild the recipe from the current canonical version.
3. Keep the same cooking method unless the user changes it.
4. Avoid apologies that replace the actual fix.

## Anti-patterns
- Switching the dish class mid-thread
- Introducing extra ingredients as “helpful” improvements
- Omitting the requested appliance after the user already established it
- Writing “I’ll fix it” without actually restating the corrected recipe
