# Telegram voice-note notes

Session takeaway:
- The user may send instructions as voice notes and expects the assistant to infer the intended request from context.
- If a voice note is partially unclear, respond with the most likely interpretation instead of repeatedly asking for a rewrite.
- Only ask for clarification when the ambiguity blocks the task.
- Keep the response short; don’t make the user fight the transcript.

Example phrasing that should trigger best-effort interpretation:
- “Вот думай, как я тебе сказал, так и делай.”

Useful response style:
- Keep it short and direct.
- Avoid extra options or follow-up offers.
- “Похоже, вы просите …” is enough when the intent is clear.
