# Voice-note correction examples

## Example: classic borscht correction
- User intent: "classic Ukrainian borscht"
- Failure to avoid: adding celery, "helpful" substitutions, or turning it into an adapted recipe without being asked.
- Correct response pattern:
  1. remove the unwanted ingredient entirely
  2. restate the dish as the classic version
  3. rebuild the ingredient list from scratch
  4. keep the rewrite short and direct

## Example: correction after a bad transcript
- If the transcript is noisy, recover the core noun first.
- Treat user frustration as a signal to simplify, not to explain.
- Do not defend the previous answer; just fix it.

## Example: garbled proper names in voice (task creation)
Voice transcriptions of Ukrainian proper names are unreliable. Real session:

- Voice: «сукор залезныцей» → agent guessed «Сукор залізниця»
- Text correction: «Укры за Лизныця» → applied
- Text correction: «Укрзализница» → applied
- Final: «Укрзалізниця»

- Voice: «Ле Сников» → applied
- Text correction: «Лесников» → applied

- Voice: «опын клоу» → agent guessed «Open Cloud»
- Text correction: «Claw!!!» → applied
- Final: «Open Claw»

Pattern: trust text corrections over voice transcription guesses. Iterate until the user is satisfied — proper names often need 2–3 rounds with voice. When committing to permanent records (task titles, calendar events), prefer waiting for text confirmation of proper names rather than committing a voice-only guess.
