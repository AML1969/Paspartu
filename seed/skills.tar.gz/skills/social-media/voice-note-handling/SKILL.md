---
name: voice-note-handling
description: Handle voice messages and speech-to-text in messaging apps with best-effort transcription, confidence signaling, and clarification discipline.
category: social-media
---

# Voice-note handling

Use this skill when the user sends a voice message, audio clip, or platform-generated transcript in chat.

## Core behavior
- Prefer the platform transcript if one is provided.
- Never claim exact wording when confidence is low.
- If only part of the audio is clear, quote the clear part and mark the rest as uncertain.
- Mirror the user’s language and keep the reply concise.
- For this user, default to *very short* answers in voice-note flows unless they explicitly ask for detail.
- Do not add follow-up offers, alternatives, or “if you want, I can…” endings unless the user asks.
- Treat “думай, как я сказал, и делай” / similar phrasing as permission to infer intent from context.

## Decision rule
- If ambiguity *does not* block action, infer the most likely request and proceed.
- If ambiguity *does* block action, ask a single targeted clarification question.
- Avoid making the user repeat themselves unless absolutely necessary.

## Reply patterns
- **High confidence:** “Распознал: …”
- **Medium confidence:** “Похоже, вы сказали …, но не уверен в слове X.”
- **Low confidence:** “Разобрал не до конца. Вижу два варианта: … / …”
- **Actionable intent:** answer or act on the inferred request directly, then note the uncertainty briefly.

## Quality checks
- Do not over-explain transcription limits.
- Do not force the user into a rewrite when a best-effort interpretation is enough.
- If the user corrects the interpretation, update the assumption immediately in the same thread.

## Interpretation & intent recovery

When the goal is to recover the user's intended meaning from a rough transcript (rather than perfect the transcript itself):

1. **Identify the request type** — correction of a previous answer, recipe/instruction rewrite, casual spoken note needing cleanup.
2. **Extract anchor nouns first** — dish/object/person/place, explicit exclusions/corrections, requested constraints, required equipment.
3. **Rebuild the answer around the anchor nouns.**
4. If the user says "classic", "original", "normal", or similar, default to the canonical version.
5. If a prior response introduced an unwanted ingredient, tool, or detail, remove it completely and rewrite the result cleanly.
6. In multi-turn recipe threads, treat the current canonical recipe as sticky context until the user explicitly changes it.

**Core interpretation rule:** prefer the user's intended meaning over literal fragments, but do **not** invent new facts, ingredients, names, substitutions, or equipment.

## Proper-name pitfalls (voice transcription)

Voice transcriptions routinely mangle proper names — company names, surnames, product names, brands. Pattern: «сукор залезныцей» → Укрзалізниця, «Ле Сников» → Лесніков, «опын клоу» → Open Claw.

- If a voice-transcribed proper name sounds like gibberish — don't commit it to a permanent record (task title, recipe, calendar event) without text confirmation.
- When the user corrects a name via text/voice, apply it immediately. If the correction is still garbled by voice, ask for text confirmation on the name specifically.
- After a text correction arrives, trust it as authoritative — don't second-guess it.

## Domain-specific pitfalls

### Recipe corrections
- Do not add "helpful" vegetables, spices, proteins, or steps that were not asked for.
- Do not turn a classic dish into an adapted dish unless the user explicitly asks for adaptation.
- Do not switch the dish category mid-thread after the user has corrected it.
- If the user corrects one ingredient, re-check the whole ingredient list for drift.
- If the user specifies an appliance or method, keep it in subsequent rewrites until they change it.
- Treat the current recipe as a stateful object across turns — maintain dish identity, preserve the appliance/method once established, only change the exact ingredient or step the user corrected.

### User frustration
- If the user is frustrated, acknowledge the correction and fix the output immediately.
- Do not defend the previous answer; just fix it.
- Treat frustration as a signal to simplify, not to explain.

## References
- `references/telegram-voice-notes.md` — session-specific examples, phrasing preferences, and ambiguity handling notes.
- `references/voice-note-corrections.md` — concrete examples and correction patterns from real sessions, including proper-name iteration.
- `references/recipe-context-drift.md` — stateful recipe correction patterns: preserve dish identity, equipment, and explicit exclusions across turns.
