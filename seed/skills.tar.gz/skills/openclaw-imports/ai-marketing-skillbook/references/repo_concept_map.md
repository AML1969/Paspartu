# ericosiu/ai-marketing-skills — карта проекта (конспект)

Источник: https://github.com/ericosiu/ai-marketing-skills

## Что это

Набор «skills» (для Claude Code/AI coding agents), где skill = **workflow + скрипты + измерение результата**, а не отдельный промпт.

Общие черты категорий:
- `SKILL.md` (как запускать и что делать)
- Python-скрипты (часто с CLI)
- Конфиг через env/.env
- Артефакты (данные/логи) сохраняются локально
- Часто есть **оценка/скоринг**, пороги принятия решения, итеративные циклы

## Категории (верхнеуровнево)

| Категория | Задача | Идея/механика |
|---|---|---|
| Growth Engine | автономные маркетинг-эксперименты | гипотеза → варианты → логирование метрик → стат.оценка (bootstrap CI, Mann-Whitney) → playbook |
| Sales Pipeline | visitor → pipeline | intent scoring, роутинг лидов, дедуп, «deal resurrector» |
| Content Ops | стабильное качество контента | expert panel scoring, quality gate, редактура/итерации |
| Outbound Engine | ICP → outbound | сбор/обогащение лидов, оптимизация писем, мониторинг конкурентов |
| SEO Ops | SEO-исследования и брифы | keyword/research ops, брифы атак, оптимизация GSC |
| Finance Ops | AI CFO | cost/ROI модели, сценарии |
| Revenue Intelligence | доказать ROI контента | атрибуция, инсайты из звонков, клиентские отчеты |
| Conversion Ops | CRO и лид-магниты | аудит лендингов, превращение опросов в лид-магниты |
| Podcast Ops | podcast → много контента | нарезка/переупаковка, контент-календарь |
| Team Ops | performance/meeting ops | meeting→action, «алгоритмы» разборов |
| Sales Playbook | value-based pricing | упаковка офферов, анализ звонков, паттерны |
| Autoresearch | оптимизация контента через циклы | генерация вариантов → оценка экспертами → эволюция победителей |
| Deck Generator | генерация презентаций | консистентный стиль + сборка deck |
| YT Competitive Analysis | разбор YouTube-каналов | outliers, паттерны упаковки (titles/thumbs) |
| X Longform | длинные посты + humanizer | анти-«AI slop» чеклисты, паттерны |
| Clone Site | клон сайта | reverse-engineering дизайна, сборка страниц |

## Сквозные “rails” (важное)

### Security sanitizer
- `security/sanitizer.py` + `security/sanitizer-config.json`
- Цель: найти/редактировать PII/секреты (email, phone, API keys, Bearer, IP, url creds, суммы, company/person blocklist).

### Skill safety rails (CI)
- `.yml` проверка PII и консистентности README (в repo это CTA-проверка).

### Telemetry (opt-in)
- Локальные логи использования: `~/.ai-marketing-skills/analytics/skill-usage.jsonl`
- Remote отправка только при opt-in.
- Собирают только “мета” (skill name, duration, ok/fail, version, OS), без контента.
