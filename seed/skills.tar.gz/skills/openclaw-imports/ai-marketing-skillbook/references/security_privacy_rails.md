# Safety rails: PII/секреты + телеметрия (конспект)

## PII/Sensitive data sanitizer (идея из repo)

Назначение: перед тем как публиковать/шарить/коммитить артефакты, прогнать сканер, который ловит:
- email/phone
- API keys (форматы `sk-...`, `ghp_...`, `Bearer ...`, `KEY=value`)
- публичные IP
- URL с логином/паролем
- суммы
- company/person blocklist (конфиг)

В repo:
- `security/sanitizer.py` (std lib only)
- `security/sanitizer-config.json`
- pre-commit hook
- CI job (`skill-safety.yml`) блокирует PR при нахождении PII

### Как применять у нас (принцип)

- Перед публикацией HTML/отчетов/экспортов: проверка на секреты и PII.
- “Сырые” экспорты держать в непубличных местах (у нас уже исключен `media/inbound/`).
- Для пакетов “CLEAN” и публичных ссылок: удалять первичку анализов/лаборатории и т.п. по требованиям.

## Telemetry (opt-in)

В repo:
- локальные логи всегда
- remote только при opt-in
- собирают мета-данные (skill, duration, success, version, OS), не контент

### Как применять у нас

- Локальные логи исполнения пайплайнов полезны (duration/ok/fail, ссылки на выход).
- Любые remote-отправки только по явному решению пользователя.
