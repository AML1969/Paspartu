# Паттерны workflow-скилов (по мотивам ai-marketing-skills)

## 1) Skill = workflow + артефакты + измеримость

Минимальный “скелет”:
- `SKILL.md`: что это, когда использовать, команды, workflow, env vars.
- `scripts/*.py` или `*.py` в корне: детерминированные шаги.
- `data/` (или заданный через env data dir): хранение артефактов.
- Четкие пороги/правила принятия решения (score ≥ X, p < Y, lift ≥ Z).

## 2) CLI-first дизайн

Почти везде удобно держать интерфейс в стиле:

- `python3 tool.py create ...`
- `python3 tool.py log ...`
- `python3 tool.py score ...`
- `python3 tool.py list ...`

Плюсы:
- агенту проще запускать по шагам,
- легко повторять и автоматизировать (cron),
- результат предсказуем.

## 3) Разделение этапов

Рекомендуемая декомпозиция:

1) **Input/ingest**: собрать данные (экспорт, API, файлы)
2) **Normalize**: привести к единому формату (таблица/JSONL)
3) **Evaluate**: скоринг/экспертная оценка/статистика
4) **Decide**: keep/discard/trending + next steps
5) **Output**: отчет/брив/плейбук
6) **Publish** (опционально): стабильный URL + версии

## 4) Quality Gate (контент)

Шаблон:
- есть rubric (критерии), шкалы, веса,
- есть “экспертная панель” (несколько ролей),
- агент итеративно улучшает текст до порога (например 90+),
- финально: чеклист “не слоп” (anti-AI-slop patterns).

Практика: хранить rubric/экспертов как отдельные файлы в `references/`.

## 5) Experiment Engine (рост/маркетинг)

Ключевые элементы:
- сущность Experiment: hypothesis, variable, variants, metric
- логирование datapoints (variant → metrics)
- статистика: bootstrap CI, non-param tests (например Mann–Whitney)
- решение winner: одновременно p-value и minimum lift
- авто-пополнение “playbook” победителями

## 6) Safety rails рядом с workflow

- PII/secret scan перед публикацией/коммитом
- opt-in telemetry (если нужно), но локальные логи всегда полезны

## 7) Архитектура для повторяемости

- Все input/output пути параметризуются.
- Никаких “магических” зависимостей от окружения.
- Для внешних интеграций: явные env vars (URL, токены).
