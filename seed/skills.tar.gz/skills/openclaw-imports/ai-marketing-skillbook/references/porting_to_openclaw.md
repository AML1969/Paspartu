# Как переносить подход ai-marketing-skills в OpenClaw (наши реалии)

## Где хранить “skills” и артефакты

- Skill-документация: `skills/<skill-name>/SKILL.md` + `references/`.
- Исполняемые пайплайны: `scripts/` (Python/Bash), чтобы запускать детерминированно.
- Публикация на сайт: `/var/www/paspartu.online/...` (стабильный URL).

## Публикация HTML-отчетов (паттерн)

- Держать **stable URL** (`.../index.html`).
- (Если нужно) держать `versions/<timestamp>/index.html`.
- После правок проверять права: `chmod 644 index.html`.
- Делать простой HTTP-check (200).

## Vault/Postgres

- Для зеркалирования файлов/доков использовать наш `scripts/vault_sync_all_run.py`.
- Важно: не зеркалить сырые импорты/секреты (у нас уже исключен `media/inbound/` и `state/postgres/*.env`).

## Как проектировать новые пайплайны

1) Определить вход (файлы/экспорт/API) и формат нормализации.
2) Написать CLI-скрипт, который делает один шаг детерминированно.
3) Добавить “gate”: проверка качества/полноты/секретов.
4) Сформировать output (HTML/MD/CSV) в предсказуемом месте.
5) (Если нужно) publish на сайт + версии.
6) sync в vault/Postgres.

## Быстрый шаблон (мысленно)

- `scripts/<pipeline>.py`:
  - `--input ... --output ... --json`
  - exit codes: 0 ok, 1 warnings/alerts
- `skills/<pipeline-skill>/SKILL.md`: как запускать и где искать артефакты.
