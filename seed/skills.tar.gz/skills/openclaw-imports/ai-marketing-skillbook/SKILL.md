---
name: ai-marketing-skillbook
description: Notes and reusable playbooks distilled from the GitHub project ericosiu/ai-marketing-skills (AI marketing and sales workflows). Use when designing or implementing AI-driven marketing ops pipelines: growth experiments, content quality scoring gates, outbound automation, SEO ops, conversion audits, revenue attribution, deck generation, site cloning, telemetry and PII safety rails, or when asked to port or replicate “Claude Code marketing skills” patterns inside OpenClaw.
---

# AI Marketing Skillbook (конспект)

Цель, быстро вспомнить, как устроены «не просто промпты, а workflows» из проекта `ericosiu/ai-marketing-skills`, и как собирать похожие пайплайны у нас (OpenClaw, сайт paspartu.online, vault/Postgres).

## Быстрый выбор, что читать

1) Нужна карта навыков (что за категории, что внутри) → `references/repo_concept_map.md`

2) Нужно собрать новый пайплайн «как в repo» (CLI-скрипт, конфиг, логирование, quality gate, eval) → `references/workflow_patterns.md`

3) Нужны safety rails (PII sanitizer, opt-in telemetry) → `references/security_privacy_rails.md`

4) Нужно «перенести» подход в OpenClaw (структура папок, публикация на сайт, версионирование, синк в vault/Postgres) → `references/porting_to_openclaw.md`

## Нормы

- Делать навыки как **workflow + скрипты + измеримость**, а не «простыню промптов».
- Разделять: **сбор данных** → **оценка/скоринг** → **вывод/репорт** → **публикация/версии**.
- Перед публикацией или шарингом: проверка на секреты/PII.
- Артефакты: хранить на сервере; при необходимости зеркалить в vault/Postgres.
