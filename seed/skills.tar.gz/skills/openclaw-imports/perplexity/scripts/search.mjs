#!/usr/bin/env node
import { readFileSync } from "node:fs";

const args = process.argv.slice(2);

// Parse args
const queries = [];
let jsonOutput = false;

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  if (arg === "--json") {
    jsonOutput = true;
  } else if (!arg.startsWith("-")) {
    queries.push(arg);
  }
}

if (queries.length === 0) {
  console.error("Usage: search.mjs <query> [query2] [query3...] [--json]");
  process.exit(1);
}

// Hermes strips provider API keys from terminal/sandbox env on purpose
// (security hardening, GHSA-rhgp-j443-p4rf), so process.env.PERPLEXITY_API_KEY
// is usually empty when the bot runs this via the terminal tool. Reading the
// .env FILE is not sanitized, so fall back to it.
let apiKey = process.env.PERPLEXITY_API_KEY;
if (!apiKey) {
  const envPath = process.env.HERMES_ENV
    || (process.env.HERMES_HOME ? `${process.env.HERMES_HOME}/.env` : "/root/.hermes/.env");
  try {
    for (const line of readFileSync(envPath, "utf8").split("\n")) {
      if (line.startsWith("PERPLEXITY_API_KEY=")) {
        apiKey = line.slice("PERPLEXITY_API_KEY=".length).trim().replace(/^["']|["']$/g, "");
        break;
      }
    }
  } catch (_) { /* fall through to the error below */ }
}
if (!apiKey) {
  console.error("Error: PERPLEXITY_API_KEY not found (env or .env file)");
  process.exit(1);
}

const MODEL = process.env.PERPLEXITY_MODEL || "sonar";

async function ask(query) {
  const response = await fetch("https://api.perplexity.ai/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "Accept": "application/json",
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: "system", content: "You are a web research assistant. Answer concisely and include citations/URLs when available." },
        { role: "user", content: query },
      ],
      temperature: 0.2,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Perplexity API error (${response.status}): ${error}`);
  }

  return response.json();
}

function format(result, query) {
  const choice = result?.choices?.[0];
  const content = choice?.message?.content ?? "";
  const citations = result?.citations || choice?.citations || [];

  const lines = [];
  lines.push(`## ${query}`);
  lines.push("");
  lines.push(content.trim() || "(no content)");

  if (Array.isArray(citations) && citations.length) {
    lines.push("");
    lines.push("Sources:");
    for (const c of citations) lines.push(`- ${c}`);
  }

  return lines.join("\n");
}

try {
  const results = [];
  for (const q of queries) {
    // Sequential to avoid bursts and keep output aligned
    results.push(await ask(q));
  }

  if (jsonOutput) {
    console.log(JSON.stringify(queries.length === 1 ? results[0] : results, null, 2));
  } else {
    for (let i = 0; i < queries.length; i++) {
      console.log(format(results[i], queries[i]));
      if (i !== queries.length - 1) console.log("\n---\n");
    }
  }
} catch (error) {
  console.error(`Error: ${error.message}`);
  process.exit(1);
}
