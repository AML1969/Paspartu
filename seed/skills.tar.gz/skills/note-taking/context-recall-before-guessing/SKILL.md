---
name: context-recall-before-guessing
description: Use when a detail is uncertain or the user references prior work. Search old sessions and memory files before guessing or asking.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [recall, memory, session-search, context, clarification]
    related_skills: [obsidian]
---

# Context Recall Before Guessing

## Overview
Use this skill when a fact, preference, file path, model, recipe variant, or prior decision is not confidently known.

The goal is simple: **verify first, guess last**. Search the conversation history and memory files before answering from memory.

## When to Use
- The user refers to something from an earlier chat or voice note
- A model, file, recipe, setting, or preference is unclear
- The user says you are missing context or changing an established detail
- You need to know whether a previous decision was already fixed

## Workflow
1. **Search past sessions first.**
   - Use `session_search(query=...)` with the most relevant terms.
   - If needed, search variants of the same phrase, dish, model, or file name.

2. **Check memory files.**
   - Read `MEMORY.md`, `USER.md`, and any dated `memory/YYYY-MM-DD.md` files that exist in the active workspace/context.
   - Prefer explicit written memory over inference.

3. **Use the strongest evidence available.**
   - A direct file note beats a fuzzy recollection.
   - A recent explicit user correction beats an older assumption.
   - If sources disagree, follow the newest explicit instruction.

4. **Do not fill gaps with invention.**
   - If the detail is still unresolved, say it is unknown.
   - Ask a focused clarification only when the missing detail blocks the task.

## Common Pitfalls
1. **Guessing from partial context.** Even a good guess is still a guess.
2. **Skipping session search because the answer feels familiar.** Familiar is not verified.
3. **Ignoring dated memory files.** They often contain the exact detail the user wants preserved.
4. **Over-asking.** Search first; ask only when the result is still ambiguous.

## Verification Checklist
- [ ] Searched old sessions when the detail was uncertain
- [ ] Checked memory files before answering
- [ ] Used the newest explicit user instruction when sources conflicted
- [ ] Avoided guessing when evidence was missing
- [ ] Asked a clarification only if the task still could not proceed
