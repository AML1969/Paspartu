# Kiwi MCP Setup Reference (BIF copy)

## Already configured in this image
Kiwi MCP is baked into the seed config (`mcp_servers.kiwi`) and the `mcp` Python package
(mcp==1.26.0, via the hermes-agent[mcp] extra) is installed in the Hermes venv at image
build time. No manual install is needed for a fresh copy.

If you ever need to (re)install the client manually, install it INTO the Hermes venv
(NOT system-wide — a plain `pip install mcp` into the wrong environment will NOT work and
was the original failure):

    pipx runpip hermes-agent install "mcp==1.26.0"

## Config (already present in config.yaml)

    mcp_servers:
      kiwi:
        url: https://mcp.kiwi.com
        timeout: 180
        connect_timeout: 60

## Tool provided
`kiwi:search-flight` — origin/destination (city or IATA code), dates (with +-3 day
flexibility), cabin class, passengers (adult/child/infant), one-way or round-trip.
Returns curated flight options with direct per-itinerary booking links.
(Also exposes `kiwi:feedback-to-devs`.)

## Activation & check
MCP servers are discovered at Hermes startup - a restart is required after config changes.
Verify with:  hermes mcp test kiwi   (expect: OK Connected + search-flight discovered).

## Why MCP > browser scraping for Kiwi
- Kiwi web/scraping often returns absurd self-transfer routings (20-50h, airport changes).
- `search-flight` returns structured, filtered results with real booking links.
- No browser, no CAPTCHAs, instant.
- ALWAYS flag self-transfer / separate tickets / airport change on a layover to the user.
