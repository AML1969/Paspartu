# Session notes: Trade Commodity / Трофименко

Use this as a concrete example of why source triangulation matters.

## What happened
- An initial web search focused on Adamovsky/Granovsky and missed Vladimir Trofimenko.
- Bing results were noisy and returned unrelated shopping/trading pages for many query variants.
- A better result was found by opening the *article body* of a direct source and searching for the target names there.

## Working pattern
1. Search entity + relationship with exact quotes.
2. Add transliteration variants and local-language spellings.
3. When search results are noisy, open a likely source page directly and search within the page HTML/text.
4. Preserve exact source wording for the relationship label.

## Concrete sources
- https://www.pravda.com.ua/rus/news/2018/03/30/7176303/ — states that "Владимир Трофименко" was one of the investors in "Трейд Коммодити".
- https://ru.wikipedia.org/wiki/Адамовский,_Андрей_Григорьевич — states that Андрей Адамовский is an investor in "Трейд Коммодити".
- https://ru.wikipedia.org/wiki/Грановский,_Александр_Михайлович_(политик) — contains the "Трейд Коммодити" section and related business context.

## Lesson
For disputed ownership/participation questions, do not stop at the first named person. Check the company name, the article body, and transliteration variants until the relevant role is explicitly stated.
