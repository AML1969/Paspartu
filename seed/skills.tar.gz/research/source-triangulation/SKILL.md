---
name: source-triangulation
description: Verify public claims about people, companies, and relationships by triangulating direct open-web sources instead of trusting search snippets or a single page.
version: 1.0.0
author: Hermes
tags: [research, verification, OSINT, fact-checking, source-checking]
---

# Source Triangulation

Use this skill when you need to verify a public claim about a person, company, ownership structure, partnership, investigation, or other relationship from open sources.

## Goal

Return a short, citation-backed answer that clearly separates:
- what is directly stated,
- what is inferred,
- and what remains unconfirmed.

## Core workflow

1. **Define the exact claim.**
   - Write it in one sentence.
   - Identify the key entities, roles, and relationship words (e.g. investor, co-owner, founder, partner, suspect).

2. **Search with name variants.**
   - Try quoted exact names.
   - Include transliteration variants and local-language spellings.
   - Search both the entity and the relationship terms.
   - If the topic is about a person/company relation, search the *company name plus person name*; do not start only from one person.

3. **Prefer direct mentions over snippets.**
   - Open the source page or its text body when possible.
   - Search inside the page for the exact names and relationship terms.
   - Extract the line or paragraph that states the claim.

4. **Triangulate.**
   - Try to confirm the same fact in at least two independent sources.
   - If only one source is available, label it as single-source evidence.
   - For disputed or sensitive claims, distinguish:
     - direct statement,
     - allegation,
     - court/report mention,
     - editorial summary.

5. **Classify the relationship carefully.**
   - Do not collapse terms like *investor*, *owner*, *co-owner*, and *partner* into one another.
   - Preserve the wording used by the source.
   - If sources disagree, report the disagreement instead of smoothing it over.

6. **Stop when you have enough.**
   - If the user asks to stop or the result is already supported, do not keep searching for more.
   - Avoid token-wasting follow-up searches once the key fact is verified.

## Pitfalls

- Search engines often return noisy, irrelevant results for named-entity queries.
- Transliteration variants matter a lot for Eastern European names.
- Snippets can mislead; always prefer the article body or page text when possible.
- A source mentioning a person in the same story does not automatically prove ownership.
- Claims about business relationships can be phrased differently across sources; keep the exact source wording.

## Output format

Prefer this structure:
- **Claim:** ...
- **Verified:** ...
- **Sources:**
  - URL — exact wording or summary
  - URL — exact wording or summary
- **Unconfirmed / disputed:** ...

## References

- See `references/source-triangulation-session-notes.md` for a concrete example and search pattern that worked on a Trade Commodity / Tрофименко investigation.