# Date rotation checklist

Use this when shifting a static site from one week/date window to another.

## Search targets
- old week range: `20–26.04.2026`, `13–19.04.2026`
- old dates: `20 апреля 2026`, `21 апреля 2026`, etc.
- old folders: `weeks/2026-04-20/`, `weeks/2026-04-13/`
- old manifest labels and slugs

## Update targets
- current week folder and labels
- previous week folder and labels
- day page titles and hero text
- TOC chips and navigation buttons
- JSON manifest paths and labels
- any CSV/file download names that embed the week date

## Verification pattern
1. Search the active site for old dates; they should disappear from the current window.
2. Search the active site for the new dates; every day page should show the correct day/date pair.
3. Search the active site for manifest strings; labels and paths must match the pages.
4. Open the current week and confirm the previous-week link points to the archived snapshot.
5. Open the previous week and confirm the next-week link points to the current snapshot.

## Common failure mode
A copied week folder is updated in visible text, but one or more internal links still point to the old folder name. Always run a second search for the old folder slug inside the copied week.
