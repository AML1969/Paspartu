---
name: date-driven-site-maintenance
description: Maintain static sites whose published content is organized by week/day/date snapshots; update live dates, archive weeks, and verify links consistently.
---

# Date-driven site maintenance

Use this skill when a site is structured around date-stamped pages, weekly snapshots, archives, or rotating content windows and you need to shift the visible period without breaking navigation.

## Typical use cases
- weekly menu sites
- calendar/schedule pages
- archive/current-week rotations
- generated static sites with `weeks/YYYY-MM-DD/` style folders

## Core workflow
1. **Find the canonical date sources first.**
   - Inspect the week index, day pages, navigation, and any machine-readable manifest.
   - Identify both the visible labels and the URL/folder names.
2. **Update the week as a set, not page by page.**
   - Change the current week folder, the previous week folder, and any references between them.
   - Copy or rename the snapshot so archived weeks remain intact unless the task explicitly asks for removal.
3. **Rewrite all date surfaces together.**
   - page titles
   - hero/meta labels
   - day-of-week chips and day headings
   - navigation links
   - manifest/JSON labels or slugs
4. **Verify old dates are gone and new dates are complete.**
   - Search for the old week range and all day dates.
   - Search for the new week range and confirm every page reports the same period.
5. **Check the relationship between current and previous weeks.**
   - The “previous week” in the current week should point to the archived prior week.
   - The archived prior week should point forward to the new current week.

## Pitfalls
- **Copied folders can retain stale inner links.** After duplicating a week snapshot, search the new folder for the old folder name and replace it if needed.
- **One visible label is not enough.** Date text often appears in titles, hero copy, table-of-contents chips, manifest JSON, and download filenames.
- **Archive weeks often need the same link graph.** When creating a new current week, update the prior week so its “next week” points back correctly.
- **Folder names and displayed labels can diverge.** Always verify both.
- **Avoid partial edits.** If a site has a week manifest, it must match the pages.

## Verification checklist
- Search for the old week range across the site; expect zero hits in the active week.
- Confirm each day page shows the correct weekday/date pair.
- Confirm the week index shows the right current range.
- Confirm manifest/JSON labels match the visible pages.
- Confirm navigation links between current and previous weeks are symmetrical.

## Practical note
When updating a published date window, prefer a narrow, mechanical replacement pass followed by a search-based audit rather than editing individual pages ad hoc.

## Reference
- See `references/date-rotation-checklist.md` for a compact checklist and example search patterns.
