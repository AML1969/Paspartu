---
name: task-cancellation-safety
description: Handle explicit user cancellation, scope changes, and side-effect boundaries without continuing work past the stop signal.
version: 1.0.0
author: Nous Research
license: MIT
---

# Task Cancellation Safety

Use this skill whenever a user cancels, narrows, or reverses an in-flight task — especially if the work involves file edits, messages, uploads, deletes, scheduling, or any other side effect.

## Trigger signals

Load this skill when the user says any of the following, or clearly means it:
- "stop"
- "cancel"
- "don't do that"
- "ignore that"
- "no need to change X"
- "I'm cancelling this"
- "don't continue"
- a scope reversal after work has already started

## Core rule

**Stop immediately.**

Do not keep executing the original task after the user has withdrawn or changed consent. Do not "finish one last step" unless the user explicitly asks for cleanup or rollback.

## Workflow

1. **Freeze the active task**
   - Stop any further tool use for the cancelled task.
   - Do not queue more edits, sends, uploads, or searches for that task.

2. **Acknowledge the cancellation briefly**
   - Confirm that you stopped.
   - Avoid a long explanation.

3. **Only ask about rollback if needed**
   - If you already made local changes and the user has not asked to revert them, ask once whether they want restoration.
   - Do not revert unprompted if the reversal itself is a side effect the user did not request.

4. **Separate cancellation from cleanup**
   - Cancellation means: no more forward progress.
   - Cleanup means: revert, delete, restore, or summarize what changed.
   - Cleanup requires explicit user direction unless it is a safe, obvious local undo that the user already asked for.

## Pitfalls

- Do **not** continue a batch of edits after the user says to stop.
- Do **not** say "I will stop" and then keep editing or searching.
- Do **not** infer permission to roll back just because the user cancelled.
- Do **not** keep explaining the previous task once cancellation is clear; keep the response short and operational.

## Side-effect boundary rules

For tasks that change external state:
- messages, email, calendar, Drive, docs, posts, webhooks, uploads, deletes, publishes

Use this sequence:
- confirm the intended action before acting, if the action is external or public
- once the user cancels, stop immediately
- if partial work happened, ask whether to revert before making more changes

## Response style after cancellation

Keep it short:
- "Stopped."
- "I paused the task."
- "I can revert the local changes if you want."

Avoid elaborate summaries unless the user asks for them.

## Related note

This skill is about *execution control*, not general planning. It complements task-specific skills that already handle confirmations for external actions.

## Support files

- `references/cancellation-patterns.md` — short examples and the session-derived pitfall that prompted this skill.
