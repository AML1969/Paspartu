# Cancellation patterns

## Session-derived pitfall

The user explicitly said to cancel a task and stop changing dates in a local site copy. The safe behavior is:
- stop immediately
- do not keep editing after the cancellation signal
- if rollback is needed, ask before reverting anything

## Practical examples

- If the user says "stop" during a multi-file edit, do not finish the remaining edits.
- If the user says "don't change dates", do not keep patching date strings or related links.
- If a task already touched local files, the next response should be a brief stop acknowledgement plus an offer to revert only if the user wants it.

## Good response shape

- "Stopped."
- "I paused the task. If you want, I can revert the local changes."
