#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Утреннее напоминание по задачам в Telegram (запускается из cron, 08:00 Киев).

Строит дайджест (старт сегодня + срок сегодня + просрочено + скоро срок) и шлёт его
в домашний чат бота через Telegram Bot API (parse_mode=HTML). Если объявлять нечего — молчит.

Нужны env (cron подгружает /root/.hermes/.env):
  TELEGRAM_BOT_TOKEN      токен бота
  TELEGRAM_HOME_CHANNEL   chat_id, куда слать (домашний чат с владельцем бота)
  TELEGRAM_HOME_CHANNEL_THREAD_ID   (опц.) тема супергруппы
Плюс те же, что и tasks.py: TASKS_DIR, HERMES_HOME.
"""
import json
import os
import sys
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tasks  # noqa: E402


def _load_env_file(p: Path):
    if not p.exists():
        return
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def send(text: str) -> None:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat = os.environ.get("TELEGRAM_HOME_CHANNEL", "")
    thread = os.environ.get("TELEGRAM_HOME_CHANNEL_THREAD_ID", "")
    if not token or not chat:
        print("ERROR: TELEGRAM_BOT_TOKEN / TELEGRAM_HOME_CHANNEL not set", file=sys.stderr)
        sys.exit(1)
    payload = {"chat_id": chat, "text": text, "parse_mode": "HTML",
               "disable_web_page_preview": True}
    if thread:
        payload["message_thread_id"] = thread
    data = urllib.parse.urlencode(payload).encode()
    req = urllib.request.Request(f"https://api.telegram.org/bot{token}/sendMessage", data=data)
    with urllib.request.urlopen(req, timeout=20) as resp:
        json.loads(resp.read())


def main():
    _load_env_file(Path(os.environ.get("HERMES_ENV", "/root/.hermes/.env")))
    txt = tasks.build_digest()
    if not txt:
        return  # тихо — нет дедлайнов сегодня и нет просрочки
    send(txt)


if __name__ == "__main__":
    main()
