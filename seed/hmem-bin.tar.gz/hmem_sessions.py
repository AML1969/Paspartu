#!/usr/bin/env python3
"""hmem_sessions — выгрузка истории сессий из state.db для дистилляции в узлы-события.

НЕ кладёт сырые транскрипты в банк. Только помогает агенту прочитать сессию и
руками/моделью выжать важное в events/ГГГГ-ММ-ДД-*.md (node_type: event).

    hmem_sessions list [--since YYYY-MM-DD] [--min-msgs N]
    hmem_sessions dump <session_id> [--max-chars 24000] [--roles user,assistant]

Только профиль Андрея (state.db = /root/.hermes/state.db).
"""
import argparse, sqlite3, sys
from datetime import datetime, timezone

DB = "/root/.hermes/state.db"


def _con():
    return sqlite3.connect(DB)


def _ts(v):
    if v is None:
        return "—"
    try:                       # epoch seconds или ISO
        if isinstance(v, (int, float)) or str(v).isdigit():
            return datetime.fromtimestamp(int(float(v)), tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
    except Exception:
        pass
    return str(v)[:16]


def cmd_list(since=None, min_msgs=0):
    c = _con()
    rows = c.execute(
        "SELECT id, started_at, ended_at, message_count, model, source, end_reason "
        "FROM sessions ORDER BY started_at").fetchall()
    out = 0
    for sid, st, en, n, model, src, reason in rows:
        if (n or 0) < min_msgs:
            continue
        sts = _ts(st)
        if since and sts[:10] < since:
            continue
        print(f"{sid}\t{sts}\t{(n or 0):>4} msg\t{model or '?'}\t{src or ''}\t{reason or ''}")
        out += 1
    print(f"\n# {out} сессий" + (f" (с {since})" if since else ""), file=sys.stderr)


def cmd_dump(session_id, max_chars=24000, roles=None):
    c = _con()
    roleset = set(r.strip() for r in roles.split(",")) if roles else None
    msgs = c.execute(
        "SELECT role, content, tool_name, timestamp FROM messages "
        "WHERE session_id=? ORDER BY id", (session_id,)).fetchall()
    if not msgs:
        sys.exit(f"нет сообщений для session_id={session_id}")
    buf, total = [], 0
    for role, content, tool, ts in msgs:
        if roleset and role not in roleset:
            continue
        content = (content or "").strip()
        if not content:
            continue
        tag = role + (f"/{tool}" if tool else "")
        line = f"[{_ts(ts)}] {tag}: {content}"
        if total + len(line) > max_chars:
            buf.append(f"… (обрезано на {max_chars} символах)")
            break
        buf.append(line)
        total += len(line)
    print("\n\n".join(buf))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="hmem_sessions")
    sub = ap.add_subparsers(dest="cmd", required=True)
    lp = sub.add_parser("list"); lp.add_argument("--since"); lp.add_argument("--min-msgs", type=int, default=0)
    dp = sub.add_parser("dump"); dp.add_argument("session_id"); dp.add_argument("--max-chars", type=int, default=24000); dp.add_argument("--roles")
    a = ap.parse_args(argv)
    if a.cmd == "list":
        cmd_list(a.since, a.min_msgs)
    elif a.cmd == "dump":
        cmd_dump(a.session_id, a.max_chars, a.roles)


if __name__ == "__main__":
    main()
